// Direction A — Minimal & calm. Linear / Mercury / Stripe-dashboard energy.
// Dark navy-black background, restrained type, soft dividers, subtle accent.

const minimalStyles = {
  bg: '#0b0d10',
  surface: '#13161b',
  surfaceHi: '#181c22',
  border: 'rgba(255,255,255,0.06)',
  borderHi: 'rgba(255,255,255,0.10)',
  text: '#e9ecef',
  textDim: '#8a9099',
  textMute: '#5b6168',
  accent: '#7c9bff', // cool indigo
  accentDim: 'rgba(124, 155, 255, 0.12)',
  green: '#5fc28a',
  amber: '#e6b450',
  red: '#ec6f6f',
  fontDisplay: "'Geist', system-ui, sans-serif",
  fontMono: "'Geist Mono', 'JetBrains Mono', monospace",
};

const MinimalDashboard = ({ connected = true }) => {
  const s = minimalStyles;
  return (
    <div style={{
      background: s.bg, color: s.text,
      fontFamily: s.fontDisplay,
      minHeight: '100%', display: 'flex',
    }}>
      <MinimalSidebar connected={connected} />
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', minWidth: 0 }}>
        <MinimalTopbar connected={connected} />
        <PageFade style={{ flex: 1, padding: '28px 32px', overflow: 'hidden' }}>
          {connected ? (
            <>
              <MinimalHeader />
              <MinimalKpiRow />
              <div style={{ display: 'grid', gridTemplateColumns: '1.5fr 1fr', gap: 20, marginTop: 20 }}>
                <MinimalPositions />
                <MinimalSidePanel />
              </div>
            </>
          ) : (
            <div style={{ display: 'grid', gridTemplateColumns: '1.5fr 1fr', gap: 20 }}>
              <MinimalConnectPanel />
              <MinimalCollateralsCard />
            </div>
          )}
        </PageFade>
      </div>
    </div>
  );
};

const MinimalConnectPanel = () => {
  const s = minimalStyles;
  return (
    <div style={{
      background: s.surface, border: `1px solid ${s.border}`,
      borderRadius: 10, overflow: 'hidden',
      display: 'flex', flexDirection: 'column',
      alignItems: 'center', justifyContent: 'center',
      padding: '64px 48px', minHeight: 560,
      position: 'relative',
    }}>
      {/* soft accent halo */}
      <div style={{
        position: 'absolute', top: -80, left: '50%', transform: 'translateX(-50%)',
        width: 320, height: 320, borderRadius: 99,
        background: s.accentDim, filter: 'blur(80px)', opacity: 0.55, pointerEvents: 'none',
      }} />
      <div style={{ position: 'relative', textAlign: 'center', maxWidth: 460 }}>
        <div style={{
          width: 56, height: 56, borderRadius: 14,
          background: s.accentDim, color: s.accent,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontSize: 24, margin: '0 auto 22px',
          border: `1px solid ${s.borderHi}`,
        }}>◐</div>
        <div style={{
          fontSize: 11.5, color: s.textDim, fontFamily: s.fontMono,
          letterSpacing: '0.06em', textTransform: 'uppercase', marginBottom: 10,
        }}>Wallet not connected</div>
        <h2 style={{
          fontSize: 32, fontWeight: 500, margin: 0,
          letterSpacing: '-0.025em',
        }}>Connect to continue</h2>
        <div style={{ fontSize: 14, color: s.textDim, marginTop: 12, lineHeight: 1.55 }}>
          Connect a wallet to open positions, mint XUSD against your collateral,
          and earn yield from the savings vault.
        </div>
        <div style={{ display: 'flex', gap: 10, marginTop: 26, justifyContent: 'center' }}>
          <button style={btnPrimary(s, { padding: '11px 20px', fontSize: 13.5 })}>Connect wallet →</button>
          <button style={btnGhost(s, { padding: '11px 20px', fontSize: 13.5 })}>Learn more</button>
        </div>

        {/* protocol stat strip */}
        <div style={{
          marginTop: 44, paddingTop: 22,
          borderTop: `1px solid ${s.border}`,
          display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16,
        }}>
          {[
            ['$24.6M', 'TVL'],
            ['$9.2M', 'Total borrowed'],
            ['8.4%', 'Savings APY'],
          ].map(([v, k]) => (
            <div key={k}>
              <div style={{ fontFamily: s.fontMono, fontSize: 22, color: s.text }}>{v}</div>
              <div style={{
                fontSize: 11, color: s.textDim, fontFamily: s.fontMono,
                letterSpacing: '0.06em', textTransform: 'uppercase', marginTop: 4,
              }}>{k}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

const MinimalSidebar = ({ connected = true }) => {
  const s = minimalStyles;
  const items = [
    { label: 'Overview', icon: '◐', active: true },
    { label: 'Borrow', icon: '↓' },
    { label: 'Earn', icon: '↑' },
    { label: 'Markets', icon: '◇' },
    { label: 'Activity', icon: '≡' },
  ];
  return (
    <div style={{
      width: 220, background: s.bg,
      borderRight: `1px solid ${s.border}`,
      padding: '24px 16px',
      display: 'flex', flexDirection: 'column', gap: 4,
    }}>
      <div style={{
        padding: '4px 12px 22px', display: 'flex', alignItems: 'center', gap: 10,
      }}>
        <div style={{
          fontSize: 22, fontWeight: 600, letterSpacing: '-0.02em',
          fontFamily: s.fontDisplay,
        }}>XIVE</div>
        <div style={{
          fontSize: 10, padding: '2px 6px', borderRadius: 4,
          background: s.accentDim, color: s.accent,
          fontFamily: s.fontMono, letterSpacing: '0.05em',
        }}>BETA</div>
      </div>
      {items.map((it, i) => {
        const dimmed = !connected && it.label !== 'Overview' && it.label !== 'Markets';
        return (
          <div key={it.label} style={{
            padding: '8px 12px', borderRadius: 6,
            fontSize: 13.5, color: it.active ? s.text : s.textDim,
            background: it.active ? s.surface : 'transparent',
            display: 'flex', alignItems: 'center', gap: 10,
            cursor: 'pointer',
            opacity: dimmed ? 0.5 : 1,
            transition: 'all 150ms',
          }}>
            <span style={{ fontSize: 13, opacity: 0.7, width: 14 }}>{it.icon}</span>
            <span>{it.label}</span>
          </div>
        );
      })}
      <div style={{ flex: 1 }} />
      {/* footer */}
      {connected ? (
        <div style={{
          padding: '12px', borderRadius: 8, background: s.surface,
          border: `1px solid ${s.border}`, fontSize: 12,
        }}>
          <div style={{ color: s.textDim, marginBottom: 4 }}>Health</div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
            <span style={{ width: 6, height: 6, borderRadius: 99, background: s.green }} />
            <span style={{ fontSize: 12.5 }}>All systems normal</span>
          </div>
          <div style={{ color: s.textMute, fontSize: 11, fontFamily: s.fontMono }}>v0.4.2 · uptime 99.98%</div>
        </div>
      ) : (
        <div style={{
          padding: '12px', borderRadius: 8, background: s.surface,
          border: `1px solid ${s.border}`, fontSize: 12,
        }}>
          <div style={{ color: s.textDim, marginBottom: 6, fontFamily: s.fontMono, fontSize: 11, letterSpacing: '0.06em', textTransform: 'uppercase' }}>Protocol</div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <span style={{ width: 6, height: 6, borderRadius: 99, background: s.green }} />
            <span style={{ fontSize: 12.5 }}>Live · Mainnet</span>
          </div>
        </div>
      )}
    </div>
  );
};

const MinimalTopbar = ({ connected = true }) => {
  const s = minimalStyles;
  return (
    <div style={{
      height: 56, borderBottom: `1px solid ${s.border}`,
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      padding: '0 32px',
    }}>
      <div style={{
        display: 'flex', alignItems: 'center', gap: 8,
        fontSize: 12, color: s.textDim,
      }}>
        <span style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <span style={{ width: 6, height: 6, borderRadius: 99, background: s.green, boxShadow: `0 0 0 3px ${s.green}22` }} />
          ETH $3,400.20
        </span>
        <span style={{ color: s.textMute }}>·</span>
        <span style={{ color: s.green, fontFamily: s.fontMono, fontSize: 12 }}>+2.14%</span>
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
        {connected ? (
          <>
            <div style={{
              padding: '6px 10px', borderRadius: 6,
              border: `1px solid ${s.border}`, fontSize: 12,
              color: s.textDim, fontFamily: s.fontMono,
              display: 'flex', alignItems: 'center', gap: 8,
            }}>
              <span style={{ width: 6, height: 6, borderRadius: 99, background: s.green }} />
              0x84f2…3e1c
            </div>
            <div style={{
              width: 30, height: 30, borderRadius: 99,
              background: `linear-gradient(135deg, ${s.accent}, #c084fc)`,
            }} />
          </>
        ) : (
          <button style={btnPrimary(s, { padding: '8px 14px', fontSize: 12.5 })}>Connect wallet →</button>
        )}
      </div>
    </div>
  );
};

const MinimalHeader = () => {
  const s = minimalStyles;
  return (
    <div style={{ marginBottom: 24 }}>
      <div style={{ fontSize: 12, color: s.textDim, marginBottom: 6, fontFamily: s.fontMono, letterSpacing: '0.04em' }}>OVERVIEW</div>
      <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between' }}>
        <h1 style={{
          fontSize: 30, fontWeight: 500, margin: 0,
          letterSpacing: '-0.025em',
        }}>Good evening, Alex.</h1>
        <div style={{ display: 'flex', gap: 8 }}>
          <button style={btnGhost(s)}>Earn XUSD</button>
          <button style={btnPrimary(s)}>Borrow →</button>
        </div>
      </div>
    </div>
  );
};

const btnPrimary = (s, extra = {}) => ({
  background: s.text, color: s.bg,
  border: 'none', padding: '8px 14px',
  fontSize: 13, fontWeight: 500, borderRadius: 6,
  cursor: 'pointer', fontFamily: s.fontDisplay,
  letterSpacing: '-0.01em',
  ...extra,
});
const btnGhost = (s, extra = {}) => ({
  background: 'transparent', color: s.text,
  border: `1px solid ${s.borderHi}`,
  padding: '8px 14px', fontSize: 13, fontWeight: 500, borderRadius: 6,
  cursor: 'pointer', fontFamily: s.fontDisplay,
  ...extra,
});

const MinimalKpiRow = () => {
  const s = minimalStyles;
  const kpis = [
    { label: 'Net worth', val: <TickerUSD to={11180} />, delta: '+$240', deltaPos: true, sub: 'last 24h' },
    { label: 'Total borrowed', val: <TickerUSD to={6500} />, sub: '0.5% APR' },
    { label: 'Earning', val: <TickerUSD to={5047} />, sub: '8.4% APY', accent: true },
    { label: 'Health factor', val: <TickerNum to={2.19} suffix="×" decimals={2} />, sub: 'liq. at $2,320', good: true },
  ];
  return (
    <div style={{
      display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)',
      gap: 0,
      border: `1px solid ${s.border}`, borderRadius: 10,
      background: s.surface, overflow: 'hidden',
    }}>
      {kpis.map((k, i) => (
        <div key={k.label} style={{
          padding: '20px 22px',
          borderRight: i < kpis.length - 1 ? `1px solid ${s.border}` : 'none',
        }}>
          <div style={{ fontSize: 11.5, color: s.textDim, fontFamily: s.fontMono, letterSpacing: '0.04em', textTransform: 'uppercase' }}>{k.label}</div>
          <div style={{
            fontSize: 28, fontWeight: 500, marginTop: 6,
            letterSpacing: '-0.02em',
            fontFamily: s.fontMono,
            color: k.good ? s.green : k.accent ? s.accent : s.text,
          }}>{k.val}</div>
          <div style={{ fontSize: 12, color: s.textDim, marginTop: 4, fontFamily: s.fontMono }}>
            {k.delta && <span style={{ color: k.deltaPos ? s.green : s.red, marginRight: 6 }}>{k.delta}</span>}
            {k.sub}
          </div>
        </div>
      ))}
    </div>
  );
};

const MinimalPositions = () => {
  const s = minimalStyles;
  const rows = [
    { token: 'ETH', col: '4.20', colUsd: 14280, debt: 6500, ltv: 46, health: 2.19 },
    { token: 'wBTC', col: '0.18', colUsd: 12150, debt: 4800, ltv: 39, health: 2.53 },
    { token: 'stETH', col: '2.50', colUsd: 8520, debt: 5200, ltv: 61, health: 1.64 },
  ];
  return (
    <div style={{
      background: s.surface, border: `1px solid ${s.border}`,
      borderRadius: 10, overflow: 'hidden',
    }}>
      <div style={{
        padding: '14px 18px',
        display: 'flex', justifyContent: 'space-between', alignItems: 'center',
        borderBottom: `1px solid ${s.border}`,
      }}>
        <div style={{ fontSize: 14, fontWeight: 500 }}>Your positions</div>
        <div style={{ fontSize: 12, color: s.textDim, cursor: 'pointer' }}>View all →</div>
      </div>

      {/* table header */}
      <div style={{
        display: 'grid', gridTemplateColumns: '1.4fr 1fr 1fr 1.5fr 80px',
        gap: 16, padding: '10px 18px',
        fontSize: 11, color: s.textDim, fontFamily: s.fontMono,
        letterSpacing: '0.04em', textTransform: 'uppercase',
        borderBottom: `1px solid ${s.border}`,
      }}>
        <div>Position</div>
        <div style={{ textAlign: 'right' }}>Collateral</div>
        <div style={{ textAlign: 'right' }}>Debt</div>
        <div>LTV</div>
        <div style={{ textAlign: 'right' }}>Health</div>
      </div>

      {rows.map((r, i) => (
        <StaggerItem key={r.token} delay={400 + i * 80}>
          <div style={{
            display: 'grid', gridTemplateColumns: '1.4fr 1fr 1fr 1.5fr 80px',
            gap: 16, padding: '14px 18px', alignItems: 'center',
            borderBottom: i < rows.length - 1 ? `1px solid ${s.border}` : 'none',
            cursor: 'pointer', transition: 'background 150ms',
          }} onMouseEnter={e => e.currentTarget.style.background = s.surfaceHi}
             onMouseLeave={e => e.currentTarget.style.background = 'transparent'}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <div style={{
                width: 30, height: 30, borderRadius: 99,
                background: s.surfaceHi, border: `1px solid ${s.borderHi}`,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontSize: 12, fontFamily: s.fontMono, fontWeight: 500,
              }}>{r.token.slice(0,2)}</div>
              <div>
                <div style={{ fontSize: 13.5, fontWeight: 500 }}>{r.token} position</div>
                <div style={{ fontSize: 11, color: s.textMute, fontFamily: s.fontMono }}>#100{i+1}</div>
              </div>
            </div>
            <div style={{ textAlign: 'right', fontFamily: s.fontMono, fontSize: 13 }}>
              <div>{r.col}</div>
              <div style={{ fontSize: 11, color: s.textMute }}>${r.colUsd.toLocaleString()}</div>
            </div>
            <div style={{ textAlign: 'right', fontFamily: s.fontMono, fontSize: 13 }}>
              ${r.debt.toLocaleString()}
              <div style={{ fontSize: 11, color: s.textMute }}>XUSD</div>
            </div>
            <div>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 11, color: s.textDim, fontFamily: s.fontMono, marginBottom: 5 }}>
                <span>{r.ltv}%</span>
                <span style={{ color: s.textMute }}>max 80%</span>
              </div>
              <AnimBar
                pct={r.ltv}
                color={r.ltv > 60 ? s.amber : s.accent}
                track="rgba(255,255,255,0.05)"
                height={4}
                delay={500 + i * 100}
              />
            </div>
            <div style={{
              textAlign: 'right', fontFamily: s.fontMono, fontSize: 13,
              color: r.health < 1.5 ? s.amber : s.green,
            }}>{r.health}×</div>
          </div>
        </StaggerItem>
      ))}
    </div>
  );
};

const MinimalCollateralsCard = () => {
  const s = minimalStyles;
  const [hover, setHover] = React.useState(null);

  const rows = [
    {
      sym: 'ETH', name: 'Ether', glyph: 'Ξ',
      maxLtv: 80, liqThreshold: 85, price: 3284.50,
      bg: 'rgba(99, 102, 241, 0.12)', fg: s.accent,
    },
    {
      sym: 'wBTC', name: 'Wrapped Bitcoin', glyph: '₿',
      maxLtv: 75, liqThreshold: 82, price: 67420.00,
      bg: 'rgba(247, 147, 26, 0.14)', fg: '#f7931a',
    },
  ];

  return (
    <div style={{
      background: s.surface, border: `1px solid ${s.border}`,
      borderRadius: 10, overflow: 'hidden',
    }}>
      <div style={{
        padding: '16px 20px 12px',
        display: 'flex', justifyContent: 'space-between', alignItems: 'center',
        borderBottom: `1px solid ${s.border}`,
      }}>
        <div style={{
          fontSize: 11.5, color: s.textDim, fontFamily: s.fontMono,
          letterSpacing: '0.04em', textTransform: 'uppercase',
        }}>Accepted collaterals</div>
        <div style={{ fontSize: 11, color: s.textMute, fontFamily: s.fontMono }}>2 assets</div>
      </div>

      {/* column header */}
      <div style={{
        padding: '10px 20px',
        display: 'grid',
        gridTemplateColumns: '1.4fr 0.8fr 0.9fr 1fr',
        gap: 12,
        fontSize: 10.5, color: s.textMute, fontFamily: s.fontMono,
        letterSpacing: '0.05em', textTransform: 'uppercase',
        borderBottom: `1px solid ${s.border}`,
      }}>
        <div>Asset</div>
        <div style={{ textAlign: 'right' }}>Max LTV</div>
        <div style={{ textAlign: 'right' }}>Liq. thr.</div>
        <div style={{ textAlign: 'right' }}>Oracle</div>
      </div>

      {rows.map((r, i) => {
        const isHover = hover === i;
        return (
          <div
            key={r.sym}
            onMouseEnter={() => setHover(i)}
            onMouseLeave={() => setHover(null)}
            style={{
              position: 'relative',
              padding: '14px 20px',
              borderBottom: i < rows.length - 1 ? `1px solid ${s.border}` : 'none',
              background: isHover ? 'rgba(99, 102, 241, 0.06)' : 'transparent',
              transition: 'background 160ms ease',
              cursor: 'pointer',
            }}
          >
            <div style={{
              display: 'grid',
              gridTemplateColumns: '1.4fr 0.8fr 0.9fr 1fr',
              gap: 12, alignItems: 'center',
              opacity: isHover ? 0 : 1,
              transition: 'opacity 160ms ease',
            }}>
              {/* asset */}
              <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                <div style={{
                  width: 30, height: 30, borderRadius: 99,
                  background: r.bg, color: r.fg,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontSize: 14, fontWeight: 500,
                }}>{r.glyph}</div>
                <div>
                  <div style={{ fontSize: 13.5, fontWeight: 500 }}>{r.sym}</div>
                  <div style={{ fontSize: 11, color: s.textMute }}>{r.name}</div>
                </div>
              </div>

              {/* max ltv */}
              <div style={{
                textAlign: 'right', fontFamily: s.fontMono, fontSize: 13,
              }}>{r.maxLtv}<span style={{ color: s.textMute }}>%</span></div>

              {/* liq threshold */}
              <div style={{
                textAlign: 'right', fontFamily: s.fontMono, fontSize: 13,
                color: s.textDim,
              }}>{r.liqThreshold}<span style={{ color: s.textMute }}>%</span></div>

              {/* oracle */}
              <div style={{
                textAlign: 'right', fontFamily: s.fontMono, fontSize: 13,
              }}>
                <span style={{ color: s.textMute }}>$</span>
                {r.price.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </div>
            </div>

            {/* hover state — open position CTA */}
            <div style={{
              position: 'absolute', inset: 0,
              display: 'flex', alignItems: 'center',
              padding: '0 20px',
              gap: 12,
              opacity: isHover ? 1 : 0,
              transform: isHover ? 'translateX(0)' : 'translateX(-4px)',
              transition: 'opacity 160ms ease, transform 160ms ease',
              pointerEvents: isHover ? 'auto' : 'none',
            }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10, flex: 1 }}>
                <div style={{
                  width: 30, height: 30, borderRadius: 99,
                  background: r.bg, color: r.fg,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontSize: 14, fontWeight: 500,
                }}>{r.glyph}</div>
                <div>
                  <div style={{ fontSize: 13.5, fontWeight: 500 }}>Borrow against {r.sym}</div>
                  <div style={{ fontSize: 11, color: s.textMute, fontFamily: s.fontMono }}>up to {r.maxLtv}% LTV</div>
                </div>
              </div>
              <button style={{
                ...btnPrimary(s),
                padding: '8px 14px',
                fontSize: 12.5,
              }}>Open position →</button>
            </div>
          </div>
        );
      })}
    </div>
  );
};

const MinimalSidePanel = () => {
  const s = minimalStyles;
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      {/* Accepted collaterals */}
      <MinimalCollateralsCard />

      {/* Activity */}
      <div style={{
        background: s.surface, border: `1px solid ${s.border}`,
        borderRadius: 10, padding: '4px 0',
      }}>
        <div style={{ padding: '16px 20px 12px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div style={{ fontSize: 11.5, color: s.textDim, fontFamily: s.fontMono, letterSpacing: '0.04em', textTransform: 'uppercase' }}>Recent activity</div>
          <div style={{ fontSize: 11, color: s.textMute, cursor: 'pointer' }}>All →</div>
        </div>
        {[
          { type: 'Borrow', amt: '+2,000 XUSD', when: '6d' },
          { type: 'Deposit', amt: '+1.20 ETH', when: '12d' },
          { type: 'Yield', amt: '+$4.80', when: '14d', good: true },
          { type: 'Open', amt: 'ETH position', when: '18d' },
        ].map((a, i) => (
          <div key={i} style={{
            padding: '10px 20px',
            display: 'flex', justifyContent: 'space-between', alignItems: 'center',
            fontSize: 13,
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <div style={{
                width: 6, height: 6, borderRadius: 99,
                background: a.good ? s.green : s.textMute,
              }} />
              <span style={{ color: s.textDim, fontSize: 12.5 }}>{a.type}</span>
            </div>
            <div style={{ fontFamily: s.fontMono, fontSize: 12.5, color: a.good ? s.green : s.text }}>
              {a.amt} <span style={{ color: s.textMute, marginLeft: 6 }}>{a.when}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

Object.assign(window, { MinimalDashboard });
