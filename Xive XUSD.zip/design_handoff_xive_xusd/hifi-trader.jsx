// Direction B — DeFi trader. Dense, terminal, mono-heavy.
// Pure black bg, sharp grids, market data prominence.

const traderStyles = {
  bg: '#000',
  surface: '#0a0a0a',
  surfaceHi: '#121212',
  border: 'rgba(255,255,255,0.08)',
  borderHi: 'rgba(255,255,255,0.14)',
  text: '#f0f0f0',
  textDim: '#9a9a9a',
  textMute: '#5a5a5a',
  accent: '#00d4a4', // terminal green
  red: '#ff5e5e',
  amber: '#ffb454',
  font: "'Geist Mono', 'JetBrains Mono', monospace",
  fontDisp: "'Geist', system-ui, sans-serif",
};

const TraderDashboard = () => {
  const s = traderStyles;
  return (
    <div style={{
      background: s.bg, color: s.text,
      fontFamily: s.font, fontSize: 12,
      minHeight: '100%', display: 'flex', flexDirection: 'column',
    }}>
      <TraderTopbar />
      <PageFade style={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
        <TraderTickerBar />
        <div style={{ flex: 1, display: 'grid', gridTemplateColumns: '1fr 320px', gap: 0 }}>
          <div style={{ padding: '14px 16px', borderRight: `1px solid ${s.border}` }}>
            <TraderKpiStrip />
            <TraderPositionsTable />
            <TraderActivityFeed />
          </div>
          <TraderRightRail />
        </div>
      </PageFade>
    </div>
  );
};

const TraderTopbar = () => {
  const s = traderStyles;
  return (
    <div style={{
      height: 44, borderBottom: `1px solid ${s.border}`,
      display: 'flex', alignItems: 'center', padding: '0 16px',
      gap: 24,
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
        <div style={{
          fontFamily: s.fontDisp, fontSize: 18, fontWeight: 600,
          letterSpacing: '-0.02em',
        }}>XIVE</div>
        <span style={{ color: s.textMute, fontSize: 11 }}>v0.4.2</span>
      </div>
      <div style={{ display: 'flex', gap: 18, fontSize: 12 }}>
        {['Overview', 'Borrow', 'Earn', 'Markets', 'History'].map((it, i) => (
          <span key={it} style={{
            color: i === 0 ? s.text : s.textDim,
            cursor: 'pointer',
            paddingBottom: 2,
            borderBottom: i === 0 ? `1px solid ${s.accent}` : '1px solid transparent',
          }}>{it}</span>
        ))}
      </div>
      <div style={{ flex: 1 }} />
      <div style={{ display: 'flex', alignItems: 'center', gap: 16, fontSize: 11.5 }}>
        <span style={{ color: s.textDim }}>BLOCK <span style={{ color: s.text }}>21,438,902</span></span>
        <span style={{ color: s.textDim }}>GAS <span style={{ color: s.amber }}>14 gwei</span></span>
        <span style={{
          padding: '3px 8px', border: `1px solid ${s.border}`,
          color: s.text, display: 'flex', alignItems: 'center', gap: 6,
        }}>
          <span style={{ width: 6, height: 6, borderRadius: 99, background: s.accent }} />
          0x84f2…3e1c
        </span>
      </div>
    </div>
  );
};

const TraderTickerBar = () => {
  const s = traderStyles;
  const items = [
    ['ETH', 3400.20, 2.14],
    ['BTC', 67432.10, 1.05],
    ['stETH', 3392.45, 2.10],
    ['XUSD', 1.0001, 0.01],
    ['XUSD APY', '8.40%', 0.12, true],
    ['TVL', '$24.6M', 0.85, true],
    ['UTIL', '68%', -1.2, true],
  ];
  return (
    <div style={{
      borderBottom: `1px solid ${s.border}`,
      padding: '8px 16px', display: 'flex', gap: 28,
      fontSize: 11.5, overflow: 'hidden',
    }}>
      {items.map(([k, v, d, raw], i) => (
        <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <span style={{ color: s.textDim }}>{k}</span>
          <span>{raw ? v : (typeof v === 'number' ? v.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 4 }) : v)}</span>
          <span style={{ color: d > 0 ? s.accent : s.red }}>{d > 0 ? '▲' : '▼'} {Math.abs(d).toFixed(2)}%</span>
        </div>
      ))}
    </div>
  );
};

const TraderKpiStrip = () => {
  const s = traderStyles;
  const kpis = [
    { l: 'NET WORTH', v: <TickerUSD to={11180} />, d: '+2.20%', g: true },
    { l: 'COLLATERAL', v: <TickerUSD to={34950} />, d: '4.20 ETH +' },
    { l: 'DEBT', v: <TickerUSD to={16500} />, d: 'AVG 0.5% APR' },
    { l: 'LTV', v: <TickerNum to={47.2} suffix="%" decimals={1} />, d: 'MAX 80%' },
    { l: 'HEALTH', v: <TickerNum to={2.19} suffix="×" decimals={2} />, d: 'GOOD', g: true },
    { l: 'EARNING', v: <TickerUSD to={5047} />, d: '8.40% APY', g: true },
  ];
  return (
    <div style={{
      display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)',
      border: `1px solid ${s.border}`, borderRadius: 0,
      marginBottom: 12,
    }}>
      {kpis.map((k, i) => (
        <div key={k.l} style={{
          padding: '12px 14px',
          borderRight: i < kpis.length - 1 ? `1px solid ${s.border}` : 'none',
        }}>
          <div style={{ fontSize: 10, color: s.textDim, letterSpacing: '0.06em', marginBottom: 4 }}>{k.l}</div>
          <div style={{
            fontSize: 20, color: k.g ? s.accent : s.text,
            letterSpacing: '-0.01em',
          }}>{k.v}</div>
          <div style={{ fontSize: 10.5, color: s.textMute, marginTop: 2 }}>{k.d}</div>
        </div>
      ))}
    </div>
  );
};

const TraderPositionsTable = () => {
  const s = traderStyles;
  const rows = [
    { tk: 'ETH',   col: 4.20,  cusd: 14280, debt: 6500, ltv: 46, lp: 2320, h: 2.19, status: 'OK' },
    { tk: 'WBTC',  col: 0.18,  cusd: 12150, debt: 4800, ltv: 39, lp: 52800, h: 2.53, status: 'OK' },
    { tk: 'STETH', col: 2.50,  cusd: 8520,  debt: 5200, ltv: 61, lp: 2640, h: 1.64, status: 'WARN' },
  ];
  return (
    <div style={{ border: `1px solid ${s.border}`, marginBottom: 12 }}>
      <div style={{
        padding: '8px 14px', display: 'flex', justifyContent: 'space-between',
        borderBottom: `1px solid ${s.border}`, alignItems: 'center',
      }}>
        <div style={{ display: 'flex', gap: 14, fontSize: 11.5 }}>
          <span style={{ color: s.text, borderBottom: `1px solid ${s.accent}`, paddingBottom: 2 }}>POSITIONS · 3</span>
          <span style={{ color: s.textDim, cursor: 'pointer' }}>HISTORY</span>
          <span style={{ color: s.textDim, cursor: 'pointer' }}>ORDERS</span>
        </div>
        <div style={{ fontSize: 11, color: s.textDim }}>
          <span style={{ marginRight: 12 }}>SORT BY HEALTH ↓</span>
          <span style={{ color: s.accent, cursor: 'pointer' }}>+ NEW POSITION</span>
        </div>
      </div>

      <div style={{
        display: 'grid',
        gridTemplateColumns: '60px 1fr 1fr 1fr 1.4fr 1fr 80px 100px',
        gap: 12, padding: '8px 14px',
        fontSize: 10, color: s.textDim, letterSpacing: '0.06em',
        borderBottom: `1px solid ${s.border}`, background: s.surface,
      }}>
        <div>ASSET</div>
        <div style={{ textAlign: 'right' }}>COLLATERAL</div>
        <div style={{ textAlign: 'right' }}>USD VALUE</div>
        <div style={{ textAlign: 'right' }}>DEBT</div>
        <div>LTV / MAX</div>
        <div style={{ textAlign: 'right' }}>LIQ. PRICE</div>
        <div style={{ textAlign: 'right' }}>HEALTH</div>
        <div style={{ textAlign: 'right' }}>STATUS</div>
      </div>

      {rows.map((r, i) => (
        <StaggerItem key={r.tk} delay={300 + i * 80}>
          <div style={{
            display: 'grid',
            gridTemplateColumns: '60px 1fr 1fr 1fr 1.4fr 1fr 80px 100px',
            gap: 12, padding: '11px 14px', alignItems: 'center',
            borderBottom: i < rows.length - 1 ? `1px solid ${s.border}` : 'none',
            fontSize: 12.5, cursor: 'pointer',
          }} onMouseEnter={e => e.currentTarget.style.background = s.surfaceHi}
             onMouseLeave={e => e.currentTarget.style.background = 'transparent'}>
            <div style={{ fontWeight: 500 }}>{r.tk}</div>
            <div style={{ textAlign: 'right' }}>{r.col.toFixed(2)}</div>
            <div style={{ textAlign: 'right' }}>${r.cusd.toLocaleString()}</div>
            <div style={{ textAlign: 'right' }}>${r.debt.toLocaleString()}</div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <span style={{ color: s.textDim, width: 32 }}>{r.ltv}%</span>
              <div style={{ flex: 1 }}>
                <AnimBar pct={r.ltv} color={r.ltv > 60 ? s.amber : s.accent} track="rgba(255,255,255,0.06)" height={3} radius={0} delay={400 + i * 100} />
              </div>
              <span style={{ color: s.textMute, width: 32, fontSize: 10.5 }}>80%</span>
            </div>
            <div style={{ textAlign: 'right', color: s.textDim }}>${r.lp.toLocaleString()}</div>
            <div style={{ textAlign: 'right', color: r.h < 1.8 ? s.amber : s.accent }}>{r.h.toFixed(2)}×</div>
            <div style={{ textAlign: 'right' }}>
              <span style={{
                fontSize: 10, padding: '2px 8px',
                color: r.status === 'OK' ? s.accent : s.amber,
                border: `1px solid ${r.status === 'OK' ? s.accent : s.amber}40`,
                background: r.status === 'OK' ? `${s.accent}10` : `${s.amber}10`,
              }}>{r.status}</span>
            </div>
          </div>
        </StaggerItem>
      ))}
    </div>
  );
};

const TraderActivityFeed = () => {
  const s = traderStyles;
  const events = [
    ['18:42:11', 'BORROW', '+2,000.00 XUSD', 'ETH-1001', s.accent],
    ['12:15:03', 'YIELD',  '+4.80 XUSD',     'SAVINGS',  s.accent],
    ['09:02:48', 'DEPOSIT','+1.20 ETH',      'ETH-1001', s.text],
    ['08:51:22', 'LIQUID.','-0.32 wBTC',     'WBTC-887', s.red],
    ['mar 14',   'OPEN',   'ETH position',   'ETH-1001', s.textDim],
  ];
  return (
    <div style={{ border: `1px solid ${s.border}` }}>
      <div style={{
        padding: '8px 14px', borderBottom: `1px solid ${s.border}`,
        fontSize: 10, color: s.textDim, letterSpacing: '0.06em',
        display: 'flex', justifyContent: 'space-between',
      }}>
        <span>ACTIVITY · LIVE</span>
        <span style={{ color: s.accent, display: 'flex', alignItems: 'center', gap: 6 }}>
          <span style={{ width: 6, height: 6, borderRadius: 99, background: s.accent, animation: 'pulse 1.6s ease-in-out infinite' }} />
          STREAMING
        </span>
      </div>
      {events.map((e, i) => (
        <div key={i} style={{
          display: 'grid', gridTemplateColumns: '90px 80px 1fr 110px',
          gap: 12, padding: '7px 14px', fontSize: 11.5,
          borderBottom: i < events.length - 1 ? `1px solid ${s.border}` : 'none',
        }}>
          <span style={{ color: s.textMute }}>{e[0]}</span>
          <span style={{ color: e[4] }}>{e[1]}</span>
          <span>{e[2]}</span>
          <span style={{ color: s.textDim, textAlign: 'right' }}>{e[3]}</span>
        </div>
      ))}
      <style>{`@keyframes pulse { 0%,100%{opacity:1} 50%{opacity:0.3} }`}</style>
    </div>
  );
};

const TraderRightRail = () => {
  const s = traderStyles;
  return (
    <div style={{ background: s.surface, padding: 14, display: 'flex', flexDirection: 'column', gap: 12 }}>
      {/* Quick action */}
      <div style={{ border: `1px solid ${s.border}`, padding: 12 }}>
        <div style={{ fontSize: 10, color: s.textDim, letterSpacing: '0.06em', marginBottom: 8 }}>QUICK BORROW</div>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 6 }}>
          <span style={{ fontSize: 11, color: s.textDim }}>DEPOSIT</span>
          <span style={{ fontSize: 11, color: s.textMute }}>BAL 5.20 ETH</span>
        </div>
        <div style={{
          padding: '8px 10px', border: `1px solid ${s.border}`,
          display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8,
        }}>
          <span style={{ fontSize: 16 }}>1.000</span>
          <span style={{ fontSize: 11.5, color: s.textDim }}>ETH</span>
        </div>
        <div style={{ fontSize: 11, color: s.textDim, marginBottom: 6 }}>BORROW</div>
        <div style={{
          padding: '8px 10px', border: `1px solid ${s.accent}40`,
          background: `${s.accent}08`,
          display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8,
        }}>
          <span style={{ fontSize: 16, color: s.accent }}>2,500.00</span>
          <span style={{ fontSize: 11.5, color: s.textDim }}>XUSD</span>
        </div>
        <button style={{
          width: '100%', padding: '9px 0',
          background: s.accent, color: s.bg,
          border: 'none', fontFamily: s.font, fontSize: 12,
          letterSpacing: '0.04em', cursor: 'pointer',
        }}>BORROW XUSD →</button>
      </div>

      {/* Risk panel */}
      <div style={{ border: `1px solid ${s.border}`, padding: 12 }}>
        <div style={{ fontSize: 10, color: s.textDim, letterSpacing: '0.06em', marginBottom: 10 }}>RISK · ETH-1001</div>
        {[
          ['CURRENT', '$3,400'],
          ['LIQ. PRICE', '$2,320'],
          ['BUFFER', '31.8%', s.accent],
          ['VOL 30D', '54%', s.amber],
        ].map(([k, v, c]) => (
          <div key={k} style={{ display: 'flex', justifyContent: 'space-between', padding: '4px 0', fontSize: 11.5 }}>
            <span style={{ color: s.textDim }}>{k}</span>
            <span style={{ color: c || s.text }}>{v}</span>
          </div>
        ))}
        <div style={{ marginTop: 12 }}>
          <div style={{ fontSize: 10, color: s.textDim, marginBottom: 4 }}>HEALTH 2.19×</div>
          <AnimBar pct={68} color={s.accent} track="rgba(255,255,255,0.06)" height={4} radius={0} delay={500} />
        </div>
      </div>

      {/* Markets mini */}
      <div style={{ border: `1px solid ${s.border}` }}>
        <div style={{
          padding: '8px 12px', borderBottom: `1px solid ${s.border}`,
          fontSize: 10, color: s.textDim, letterSpacing: '0.06em',
        }}>MARKETS</div>
        {[
          ['ETH',   '0.50%', '80%'],
          ['WBTC',  '0.50%', '75%'],
          ['STETH', '0.75%', '75%'],
          ['SOL',   '1.00%', '65%'],
        ].map(([t, apr, ltv], i, arr) => (
          <div key={t} style={{
            padding: '7px 12px', display: 'grid',
            gridTemplateColumns: '1fr 60px 60px',
            fontSize: 11.5, gap: 8,
            borderBottom: i < arr.length - 1 ? `1px solid ${s.border}` : 'none',
          }}>
            <span>{t}</span>
            <span style={{ color: s.textDim, textAlign: 'right' }}>{apr}</span>
            <span style={{ color: s.textDim, textAlign: 'right' }}>{ltv}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

Object.assign(window, { TraderDashboard });
