// Hi-fi A — Borrow + Earn screens
// Reuses minimalStyles, AnimBar, TickerUSD, TickerNum, PageFade, StaggerItem from siblings

const MinimalShell = ({ children, active = 'Overview' }) => (
  <div style={{
    background: minimalStyles.bg, color: minimalStyles.text,
    fontFamily: minimalStyles.fontDisplay, minHeight: '100%', display: 'flex',
  }}>
    <MinimalSidebarReuse active={active} />
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', minWidth: 0 }}>
      <MinimalTopbarReuse />
      <PageFade style={{ flex: 1, padding: '28px 32px', overflow: 'hidden' }}>
        {children}
      </PageFade>
    </div>
  </div>
);

const MinimalSidebarReuse = ({ active }) => {
  const s = minimalStyles;
  const items = [
    { label: 'Overview', icon: '◐' },
    { label: 'Borrow', icon: '↓' },
    { label: 'Earn', icon: '↑' },
    { label: 'Markets', icon: '◇' },
    { label: 'Activity', icon: '≡' },
  ];
  return (
    <div style={{
      width: 220, background: s.bg, borderRight: `1px solid ${s.border}`,
      padding: '24px 16px', display: 'flex', flexDirection: 'column', gap: 4,
    }}>
      <div style={{ padding: '4px 12px 22px', display: 'flex', alignItems: 'center', gap: 10 }}>
        <div style={{ fontSize: 22, fontWeight: 600, letterSpacing: '-0.02em' }}>XIVE</div>
        <div style={{
          fontSize: 10, padding: '2px 6px', borderRadius: 4,
          background: s.accentDim, color: s.accent,
          fontFamily: s.fontMono, letterSpacing: '0.05em',
        }}>BETA</div>
      </div>
      {items.map(it => (
        <div key={it.label} style={{
          padding: '8px 12px', borderRadius: 6,
          fontSize: 13.5, color: it.label === active ? s.text : s.textDim,
          background: it.label === active ? s.surface : 'transparent',
          display: 'flex', alignItems: 'center', gap: 10, cursor: 'pointer',
        }}>
          <span style={{ fontSize: 13, opacity: 0.7, width: 14 }}>{it.icon}</span>
          <span>{it.label}</span>
        </div>
      ))}
      <div style={{ flex: 1 }} />
      <div style={{
        padding: 12, borderRadius: 8, background: s.surface,
        border: `1px solid ${s.border}`, fontSize: 12,
      }}>
        <div style={{ color: s.textDim, marginBottom: 4 }}>Health</div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
          <span style={{ width: 6, height: 6, borderRadius: 99, background: s.green }} />
          <span style={{ fontSize: 12.5 }}>All systems normal</span>
        </div>
        <div style={{ color: s.textMute, fontSize: 11, fontFamily: s.fontMono }}>v0.4.2 · uptime 99.98%</div>
      </div>
    </div>
  );
};

const MinimalTopbarReuse = () => {
  const s = minimalStyles;
  return (
    <div style={{
      height: 56, borderBottom: `1px solid ${s.border}`,
      display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0 32px',
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 12, color: s.textDim }}>
        <span style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <span style={{ width: 6, height: 6, borderRadius: 99, background: s.green, boxShadow: `0 0 0 3px ${s.green}22` }} />
          ETH $3,400.20
        </span>
        <span style={{ color: s.textMute }}>·</span>
        <span style={{ color: s.green, fontFamily: s.fontMono }}>+2.14%</span>
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
        <div style={{
          padding: '6px 10px', borderRadius: 6,
          border: `1px solid ${s.border}`, fontSize: 12,
          color: s.textDim, fontFamily: s.fontMono,
          display: 'flex', alignItems: 'center', gap: 8,
        }}>
          <span style={{ width: 6, height: 6, borderRadius: 99, background: s.green }} />
          0x84f2…3e1c
        </div>
        <div style={{ width: 30, height: 30, borderRadius: 99, background: `linear-gradient(135deg, ${s.accent}, #c084fc)` }} />
      </div>
    </div>
  );
};

const mPrimary = (s, extra = {}) => ({
  background: s.text, color: s.bg, border: 'none',
  padding: '10px 16px', fontSize: 13, fontWeight: 500, borderRadius: 6,
  cursor: 'pointer', fontFamily: s.fontDisplay, letterSpacing: '-0.01em',
  ...extra,
});
const mGhost = (s, extra = {}) => ({
  background: 'transparent', color: s.text,
  border: `1px solid ${s.borderHi}`, padding: '10px 16px',
  fontSize: 13, fontWeight: 500, borderRadius: 6,
  cursor: 'pointer', fontFamily: s.fontDisplay,
  ...extra,
});
const mAccent = (s, extra = {}) => ({
  background: s.accent, color: s.bg, border: 'none',
  padding: '12px 16px', fontSize: 13, fontWeight: 600, borderRadius: 6,
  cursor: 'pointer', fontFamily: s.fontDisplay, letterSpacing: '-0.01em',
  ...extra,
});

// Reusable card
const MCard = ({ children, style, padding = 20 }) => (
  <div style={{
    background: minimalStyles.surface, border: `1px solid ${minimalStyles.border}`,
    borderRadius: 10, padding, ...style,
  }}>{children}</div>
);

const MLabel = ({ children, style }) => (
  <div style={{
    fontSize: 11, color: minimalStyles.textDim, fontFamily: minimalStyles.fontMono,
    letterSpacing: '0.06em', textTransform: 'uppercase', ...style,
  }}>{children}</div>
);

// ===========================================================
// BORROW screen
// ===========================================================
const MinimalBorrow = () => {
  const s = minimalStyles;
  return (
    <MinimalShell active="Borrow">
      <div style={{ marginBottom: 24, display: 'flex', alignItems: 'baseline', justifyContent: 'space-between' }}>
        <div>
          <MLabel>Borrow XUSD</MLabel>
          <h1 style={{ fontSize: 30, fontWeight: 500, margin: '4px 0 0', letterSpacing: '-0.025em' }}>
            Open a position
          </h1>
        </div>
        <div style={{ fontSize: 12, color: s.textDim, fontFamily: s.fontMono }}>
          step <span style={{ color: s.text }}>1</span> of 1 · review · sign
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1.1fr 1fr', gap: 20 }}>
        {/* LEFT — form */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          {/* Deposit */}
          <MCard>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 10 }}>
              <MLabel>Deposit collateral</MLabel>
              <div style={{ fontSize: 11.5, color: s.textDim, fontFamily: s.fontMono }}>balance 5.20 ETH · <span style={{ color: s.accent, cursor: 'pointer' }}>max</span></div>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
              <input
                defaultValue="4.20"
                style={{
                  flex: 1, fontFamily: s.fontMono, fontSize: 36, fontWeight: 400,
                  border: 'none', outline: 'none', background: 'transparent',
                  color: s.text, letterSpacing: '-0.02em',
                }}
              />
              <div style={{
                display: 'flex', alignItems: 'center', gap: 8,
                padding: '6px 12px', border: `1px solid ${s.borderHi}`, borderRadius: 99,
                cursor: 'pointer',
              }}>
                <div style={{
                  width: 22, height: 22, borderRadius: 99,
                  background: s.surfaceHi, fontSize: 11, display: 'flex',
                  alignItems: 'center', justifyContent: 'center', fontFamily: s.fontMono,
                }}>Ξ</div>
                <span style={{ fontWeight: 500, fontSize: 14 }}>ETH</span>
                <span style={{ color: s.textDim, fontSize: 12 }}>▾</span>
              </div>
            </div>
            <div style={{ fontSize: 12, color: s.textDim, marginTop: 4, fontFamily: s.fontMono }}>≈ $14,280.00</div>
            <div style={{ display: 'flex', gap: 6, marginTop: 14 }}>
              {['25%', '50%', '75%', 'MAX'].map(p => (
                <span key={p} style={{
                  fontSize: 11, padding: '4px 10px',
                  border: `1px solid ${s.border}`, borderRadius: 99,
                  color: s.textDim, fontFamily: s.fontMono, cursor: 'pointer',
                }}>{p}</span>
              ))}
            </div>
          </MCard>

          {/* arrow */}
          <div style={{ textAlign: 'center', fontSize: 14, color: s.textMute, margin: '-2px 0' }}>↓</div>

          {/* Borrow */}
          <MCard>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 10 }}>
              <MLabel>Borrow</MLabel>
              <div style={{ fontSize: 11.5, color: s.textDim, fontFamily: s.fontMono }}>max 11,420 XUSD</div>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
              <input
                defaultValue="6,500"
                style={{
                  flex: 1, fontFamily: s.fontMono, fontSize: 36, fontWeight: 400,
                  border: 'none', outline: 'none', background: 'transparent',
                  color: s.accent, letterSpacing: '-0.02em',
                }}
              />
              <div style={{
                display: 'flex', alignItems: 'center', gap: 8,
                padding: '6px 12px', border: `1px solid ${s.borderHi}`, borderRadius: 99,
              }}>
                <div style={{
                  width: 22, height: 22, borderRadius: 99,
                  background: s.accentDim, color: s.accent, fontSize: 11,
                  display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: s.fontMono,
                }}>$</div>
                <span style={{ fontWeight: 500, fontSize: 14 }}>XUSD</span>
              </div>
            </div>
            <div style={{ fontSize: 12, color: s.textDim, marginTop: 4, fontFamily: s.fontMono }}>≈ $6,500.00</div>

            {/* LTV slider */}
            <div style={{ marginTop: 18 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
                <span style={{ fontSize: 11.5, color: s.textDim, fontFamily: s.fontMono }}>LTV</span>
                <span style={{ fontSize: 11.5, color: s.text, fontFamily: s.fontMono }}>46% / 80%</span>
              </div>
              <AnimBar pct={46} color={s.accent} track="rgba(255,255,255,0.06)" height={6} delay={300} />
              <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 4 }}>
                <span style={{ fontSize: 10.5, color: s.textMute, fontFamily: s.fontMono }}>0%</span>
                <span style={{ fontSize: 10.5, color: s.textMute, fontFamily: s.fontMono }}>safe</span>
                <span style={{ fontSize: 10.5, color: s.textMute, fontFamily: s.fontMono }}>liq.</span>
              </div>
            </div>
          </MCard>
        </div>

        {/* RIGHT — summary */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          <MCard>
            <MLabel style={{ marginBottom: 14 }}>Summary</MLabel>
            {[
              ['Health factor', <TickerNum to={2.19} decimals={2} suffix="×" />, s.green],
              ['Liquidation price', '$2,320', s.text],
              ['Borrow APR', '0.50%', s.text],
              ['One-time fee', '0 XUSD', s.text],
              ['Network fee', '~$2.40', s.textDim],
            ].map(([k, v, c], i, arr) => (
              <div key={k} style={{
                display: 'flex', justifyContent: 'space-between',
                padding: '10px 0', fontSize: 13,
                borderBottom: i < arr.length - 1 ? `1px solid ${s.border}` : 'none',
              }}>
                <span style={{ color: s.textDim }}>{k}</span>
                <span style={{ color: c, fontFamily: s.fontMono }}>{v}</span>
              </div>
            ))}
          </MCard>

          <MCard padding={16}>
            <div style={{ display: 'flex', alignItems: 'flex-start', gap: 10 }}>
              <div style={{
                width: 6, height: 6, borderRadius: 99, background: s.accent,
                marginTop: 7, flexShrink: 0,
              }} />
              <div style={{ fontSize: 12.5, color: s.textDim, lineHeight: 1.5 }}>
                If ETH drops below <span style={{ color: s.text }}>$2,320</span>, your collateral can be sold to repay the debt. Add more ETH any time to reduce risk.
              </div>
            </div>
          </MCard>

          <button style={mAccent(s, { width: '100%', padding: '14px 0', fontSize: 14, marginTop: 4 })}>
            Borrow 6,500 XUSD →
          </button>
          <button style={mGhost(s, { width: '100%' })}>Cancel</button>
        </div>
      </div>
    </MinimalShell>
  );
};

// ===========================================================
// EARN screen
// ===========================================================
const MinimalEarn = () => {
  const s = minimalStyles;
  const [tab, setTab] = React.useState('deposit');
  return (
    <MinimalShell active="Earn">
      <div style={{ marginBottom: 24 }}>
        <MLabel>Savings vault</MLabel>
        <h1 style={{ fontSize: 30, fontWeight: 500, margin: '4px 0 0', letterSpacing: '-0.025em' }}>
          Earn yield on XUSD
        </h1>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1.2fr 1fr', gap: 20 }}>
        {/* LEFT — vault stats + position */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          <MCard padding={28}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
              <div>
                <MLabel>Current APY · 30d avg</MLabel>
                <div style={{
                  fontSize: 64, fontFamily: s.fontMono, fontWeight: 400,
                  color: s.accent, lineHeight: 1, marginTop: 8, letterSpacing: '-0.03em',
                }}><TickerNum to={8.4} decimals={1} />%</div>
              </div>
              <div style={{
                fontSize: 11, padding: '3px 8px', borderRadius: 4,
                background: 'rgba(95, 194, 138, 0.12)', color: s.green,
                fontFamily: s.fontMono,
              }}>● LIVE</div>
            </div>
            <div style={{
              marginTop: 24, paddingTop: 18, borderTop: `1px solid ${s.border}`,
              display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 14,
            }}>
              {[
                ['TVL', '$24.6M'],
                ['Utilization', '68%'],
                ['7d yield', '$152K'],
              ].map(([k, v]) => (
                <div key={k}>
                  <MLabel>{k}</MLabel>
                  <div style={{ fontSize: 18, fontFamily: s.fontMono, marginTop: 4 }}>{v}</div>
                </div>
              ))}
            </div>
          </MCard>

          <MCard>
            <MLabel style={{ marginBottom: 14 }}>Your position</MLabel>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
              <div>
                <div style={{ fontSize: 11.5, color: s.textDim, fontFamily: s.fontMono }}>DEPOSITED</div>
                <div style={{ fontFamily: s.fontMono, fontSize: 26, marginTop: 4 }}>$5,047.20</div>
                <div style={{ fontSize: 11.5, color: s.textMute, fontFamily: s.fontMono, marginTop: 2 }}>since Mar 18</div>
              </div>
              <div>
                <div style={{ fontSize: 11.5, color: s.textDim, fontFamily: s.fontMono }}>YIELD</div>
                <div style={{ fontFamily: s.fontMono, fontSize: 26, marginTop: 4, color: s.green }}>+$47.20</div>
                <div style={{ fontSize: 11.5, color: s.textMute, fontFamily: s.fontMono, marginTop: 2 }}>~$1.50/day</div>
              </div>
            </div>
            <div style={{ marginTop: 16, paddingTop: 14, borderTop: `1px solid ${s.border}` }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 11.5, color: s.textDim, fontFamily: s.fontMono, marginBottom: 6 }}>
                <span>vault share</span><span style={{ color: s.text }}>0.030%</span>
              </div>
              <AnimBar pct={20} color={s.accent} track="rgba(255,255,255,0.05)" height={3} delay={400} />
            </div>
          </MCard>

          <MCard padding={16}>
            <div style={{ fontSize: 12.5, color: s.textDim, lineHeight: 1.5 }}>
              Yield comes from positions the vault liquidates at a discount. No lockup; withdraw at any time.
            </div>
          </MCard>
        </div>

        {/* RIGHT — deposit / withdraw */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          {/* Tabs */}
          <div style={{ display: 'flex', gap: 4, padding: 4, background: s.surface, borderRadius: 8, border: `1px solid ${s.border}` }}>
            {[['deposit', 'Deposit'], ['withdraw', 'Withdraw']].map(([k, l]) => (
              <button key={k} onClick={() => setTab(k)} style={{
                flex: 1, padding: '8px 0', borderRadius: 6,
                fontSize: 13, fontWeight: 500, fontFamily: s.fontDisplay,
                border: 'none', cursor: 'pointer',
                background: tab === k ? s.surfaceHi : 'transparent',
                color: tab === k ? s.text : s.textDim,
              }}>{l}</button>
            ))}
          </div>

          {tab === 'deposit' ? (
            <>
              <MCard>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 10 }}>
                  <MLabel>Amount</MLabel>
                  <div style={{ fontSize: 11.5, color: s.textDim, fontFamily: s.fontMono }}>balance 12,300 XUSD · <span style={{ color: s.accent, cursor: 'pointer' }}>max</span></div>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                  <input defaultValue="2,500" style={{
                    flex: 1, fontFamily: s.fontMono, fontSize: 36, fontWeight: 400,
                    border: 'none', outline: 'none', background: 'transparent', color: s.text,
                    letterSpacing: '-0.02em',
                  }} />
                  <div style={{
                    padding: '6px 12px', border: `1px solid ${s.borderHi}`,
                    borderRadius: 99, fontSize: 14, fontWeight: 500,
                  }}>XUSD</div>
                </div>
                <div style={{ fontSize: 12, color: s.textDim, marginTop: 4, fontFamily: s.fontMono }}>≈ $2,500.00</div>
              </MCard>

              <MCard>
                <MLabel style={{ marginBottom: 14 }}>Projected earnings</MLabel>
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 14 }}>
                  {[['1m', '+$17.50'], ['6m', '+$105.00'], ['1y', '+$210.00']].map(([k, v]) => (
                    <div key={k}>
                      <div style={{ fontSize: 11.5, color: s.textDim, fontFamily: s.fontMono }}>{k}</div>
                      <div style={{ fontSize: 18, fontFamily: s.fontMono, marginTop: 2, color: s.green }}>{v}</div>
                    </div>
                  ))}
                </div>
              </MCard>

              <button style={mAccent(s, { width: '100%', padding: '14px 0', fontSize: 14 })}>
                Deposit 2,500 XUSD →
              </button>
            </>
          ) : (
            <>
              <MCard>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 10 }}>
                  <MLabel>Withdraw</MLabel>
                  <div style={{ fontSize: 11.5, color: s.textDim, fontFamily: s.fontMono }}>available 5,047.20</div>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                  <input defaultValue="1,000" style={{
                    flex: 1, fontFamily: s.fontMono, fontSize: 36, fontWeight: 400,
                    border: 'none', outline: 'none', background: 'transparent', color: s.text,
                  }} />
                  <div style={{ padding: '6px 12px', border: `1px solid ${s.borderHi}`, borderRadius: 99, fontSize: 14, fontWeight: 500 }}>XUSD</div>
                </div>
              </MCard>
              <button style={mAccent(s, { width: '100%', padding: '14px 0', fontSize: 14 })}>
                Withdraw 1,000 XUSD →
              </button>
            </>
          )}
        </div>
      </div>
    </MinimalShell>
  );
};

Object.assign(window, { MinimalShell, MCard, MLabel, mPrimary, mGhost, mAccent, MinimalBorrow, MinimalEarn });
