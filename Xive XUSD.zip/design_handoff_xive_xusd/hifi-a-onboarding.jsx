// Hi-fi A — Connect wallet + Empty dashboard

// ===========================================================
// CONNECT WALLET — first-time landing
// ===========================================================
const MinimalConnect = () => {
  const s = minimalStyles;
  return (
    <div style={{
      background: s.bg, color: s.text, fontFamily: s.fontDisplay,
      minHeight: '100%', display: 'flex', flexDirection: 'column',
    }}>
      {/* slim nav */}
      <div style={{
        height: 64, borderBottom: `1px solid ${s.border}`,
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        padding: '0 32px',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{ fontSize: 22, fontWeight: 600, letterSpacing: '-0.02em' }}>XIVE</div>
          <div style={{
            fontSize: 10, padding: '2px 6px', borderRadius: 4,
            background: s.accentDim, color: s.accent,
            fontFamily: s.fontMono, letterSpacing: '0.05em',
          }}>BETA</div>
        </div>
        <div style={{ display: 'flex', gap: 22, fontSize: 13, color: s.textDim }}>
          <span style={{ cursor: 'pointer' }}>Docs</span>
          <span style={{ cursor: 'pointer' }}>Markets</span>
          <span style={{ cursor: 'pointer' }}>Stats</span>
        </div>
        <button style={mAccent(s, { padding: '9px 16px', fontSize: 13 })}>Connect wallet</button>
      </div>

      <PageFade style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '40px 32px' }}>
        <div style={{ display: 'grid', gridTemplateColumns: '1.1fr 1fr', gap: 80, maxWidth: 1100, alignItems: 'center' }}>
          {/* LEFT — hero */}
          <div>
            <MLabel style={{ marginBottom: 16 }}>A stablecoin you mint yourself</MLabel>
            <h1 style={{
              fontSize: 60, fontWeight: 500, lineHeight: 1.05,
              letterSpacing: '-0.03em', margin: 0,
            }}>
              Borrow <span style={{ color: s.accent }}>XUSD</span><br/>
              against your crypto.
            </h1>
            <div style={{ fontSize: 16, color: s.textDim, marginTop: 18, lineHeight: 1.5, maxWidth: 480 }}>
              Deposit ETH or other collateral, mint XUSD at up to 80% LTV, keep your upside. Repay anytime — no fixed term.
            </div>
            <div style={{
              marginTop: 32, paddingTop: 22, borderTop: `1px solid ${s.border}`,
              display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16, maxWidth: 480,
            }}>
              {[
                ['$24.6M', 'TVL'],
                ['$9.2M', 'XUSD outstanding'],
                ['8.4%', 'Savings APY'],
              ].map(([v, k]) => (
                <div key={k}>
                  <div style={{ fontFamily: s.fontMono, fontSize: 22 }}>{v}</div>
                  <div style={{ fontSize: 11, color: s.textDim, fontFamily: s.fontMono, letterSpacing: '0.06em', textTransform: 'uppercase', marginTop: 2 }}>{k}</div>
                </div>
              ))}
            </div>
          </div>

          {/* RIGHT — connect card */}
          <MCard padding={24}>
            <MLabel style={{ marginBottom: 16 }}>Connect to continue</MLabel>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
              {[
                { name: 'MetaMask', sub: 'Most popular', dot: '🦊' },
                { name: 'WalletConnect', sub: 'Mobile wallets', dot: '◇' },
                { name: 'Coinbase Wallet', sub: '', dot: '◉' },
                { name: 'Rabby', sub: '', dot: '◐' },
              ].map(w => (
                <div key={w.name} style={{
                  padding: '12px 14px', borderRadius: 8,
                  border: `1px solid ${s.border}`, background: s.bg,
                  display: 'flex', alignItems: 'center', gap: 12, cursor: 'pointer',
                  transition: 'all 150ms',
                }} onMouseEnter={e => { e.currentTarget.style.background = s.surfaceHi; e.currentTarget.style.borderColor = s.borderHi; }}
                   onMouseLeave={e => { e.currentTarget.style.background = s.bg; e.currentTarget.style.borderColor = s.border; }}>
                  <div style={{
                    width: 32, height: 32, borderRadius: 8,
                    background: s.surfaceHi, display: 'flex',
                    alignItems: 'center', justifyContent: 'center', fontSize: 16,
                  }}>{w.dot}</div>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontSize: 14, fontWeight: 500 }}>{w.name}</div>
                    {w.sub && <div style={{ fontSize: 11.5, color: s.textDim, fontFamily: s.fontMono }}>{w.sub}</div>}
                  </div>
                  <span style={{ color: s.textMute, fontSize: 16 }}>→</span>
                </div>
              ))}
            </div>
            <div style={{ fontSize: 11.5, color: s.textMute, marginTop: 16, lineHeight: 1.5 }}>
              By connecting you agree to the <span style={{ color: s.textDim, textDecoration: 'underline', cursor: 'pointer' }}>terms</span>. Xive is non-custodial.
            </div>
          </MCard>
        </div>
      </PageFade>
    </div>
  );
};

// ===========================================================
// EMPTY DASHBOARD — wallet connected, no positions
// ===========================================================
const MinimalEmptyDash = () => {
  const s = minimalStyles;
  return (
    <MinimalShell active="Overview">
      <div style={{ marginBottom: 28 }}>
        <MLabel>Welcome to XIVE</MLabel>
        <h1 style={{ fontSize: 30, fontWeight: 500, margin: '4px 0 6px', letterSpacing: '-0.025em' }}>
          You don't have any positions yet
        </h1>
        <div style={{ fontSize: 14, color: s.textDim }}>
          Deposit collateral to mint XUSD, or earn yield by lending it.
        </div>
      </div>

      {/* Two big CTAs */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
        <MCard style={{ padding: 28, position: 'relative', overflow: 'hidden', cursor: 'pointer' }}>
          <div style={{
            position: 'absolute', top: -40, right: -40, width: 140, height: 140,
            borderRadius: 99, background: s.accentDim, opacity: 0.5, filter: 'blur(40px)',
          }} />
          <div style={{ position: 'relative' }}>
            <div style={{
              width: 36, height: 36, borderRadius: 8,
              background: s.accentDim, color: s.accent,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontSize: 18, marginBottom: 14,
            }}>↓</div>
            <div style={{ fontSize: 18, fontWeight: 500, letterSpacing: '-0.01em' }}>Borrow XUSD</div>
            <div style={{ fontSize: 13, color: s.textDim, marginTop: 4, lineHeight: 1.5, marginBottom: 18 }}>
              Deposit collateral and mint XUSD at up to 80% LTV. Keep your upside, spend dollars. Repay anytime.
            </div>
            <button style={mAccent(s)}>Open a position →</button>
          </div>
        </MCard>

        <MCard style={{ padding: 28, position: 'relative', overflow: 'hidden', cursor: 'pointer' }}>
          <div style={{ position: 'relative' }}>
            <div style={{
              width: 36, height: 36, borderRadius: 8,
              background: 'rgba(95, 194, 138, 0.12)', color: s.green,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontSize: 18, marginBottom: 14,
            }}>↑</div>
            <div style={{ fontSize: 18, fontWeight: 500, letterSpacing: '-0.01em' }}>Earn 8.4%</div>
            <div style={{ fontSize: 13, color: s.textDim, marginTop: 4, lineHeight: 1.5, marginBottom: 18 }}>
              Deposit XUSD into the savings vault. Yield comes from liquidations the vault absorbs at a discount. No lockup.
            </div>
            <button style={mGhost(s)}>Deposit XUSD →</button>
          </div>
        </MCard>
      </div>

      <div style={{ marginTop: 32 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
          <MLabel>In your wallet</MLabel>
          <span style={{ fontSize: 12, color: s.textDim, cursor: 'pointer' }}>View all →</span>
        </div>
        <MCard padding={4}>
          {[
            { s: 'Ξ', name: 'Ether', tk: 'ETH', bal: '5.20', usd: '$17,680' },
            { s: 'L', name: 'Lido stETH', tk: 'stETH', bal: '0.00', usd: '$0', empty: true },
            { s: '$', name: 'XUSD', tk: 'XUSD', bal: '0.00', usd: '$0', empty: true },
          ].map((t, i, arr) => (
            <div key={t.tk} style={{
              display: 'grid', gridTemplateColumns: '40px 1fr auto auto auto',
              gap: 12, padding: '12px 18px', alignItems: 'center',
              borderTop: i > 0 ? `1px solid ${s.border}` : 'none',
              opacity: t.empty ? 0.5 : 1,
            }}>
              <div style={{
                width: 32, height: 32, borderRadius: 99,
                background: s.surfaceHi, border: `1px solid ${s.borderHi}`,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontFamily: s.fontMono, fontSize: 12,
              }}>{t.s}</div>
              <div>
                <div style={{ fontSize: 14, fontWeight: 500 }}>{t.name}</div>
                <div style={{ fontSize: 11.5, color: s.textDim, fontFamily: s.fontMono }}>{t.tk}</div>
              </div>
              <div style={{ textAlign: 'right', fontFamily: s.fontMono, fontSize: 13.5, marginRight: 32 }}>
                {t.bal}
              </div>
              <div style={{ textAlign: 'right', fontFamily: s.fontMono, fontSize: 12, color: s.textDim, marginRight: 16 }}>
                {t.usd}
              </div>
              <button style={mGhost(s, { padding: '6px 12px', fontSize: 12 })}>Use →</button>
            </div>
          ))}
        </MCard>
      </div>
    </MinimalShell>
  );
};

Object.assign(window, { MinimalConnect, MinimalEmptyDash });
