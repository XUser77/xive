// Hi-fi A — Manage position + Confirmation modal + Tx status

// ===========================================================
// MANAGE POSITION — tabs: Add / Withdraw / Borrow / Repay / Close
// ===========================================================
const MinimalManage = ({ atRisk = false }) => {
  const s = minimalStyles;
  const [tab, setTab] = React.useState('add');

  const data = atRisk ? {
    col: '4.20', colUsd: 10920, debt: 8800,
    health: 1.05, healthLabel: 'At risk',
    liqPrice: 2580, current: 2600, ltv: 80,
  } : {
    col: '4.20', colUsd: 14280, debt: 6500,
    health: 2.19, healthLabel: 'Healthy',
    liqPrice: 2320, current: 3400, ltv: 46,
  };

  return (
    <MinimalShell active="Borrow">
      {/* breadcrumb */}
      <div style={{ fontSize: 12, color: s.textDim, marginBottom: 12, fontFamily: s.fontMono }}>
        <span style={{ cursor: 'pointer' }}>Overview</span> / ETH position #1001
      </div>

      {/* At-risk banner */}
      {atRisk && (
        <div style={{
          padding: '14px 18px', marginBottom: 20, borderRadius: 10,
          background: 'rgba(230, 180, 80, 0.08)',
          border: `1px solid rgba(230, 180, 80, 0.25)`,
          display: 'flex', alignItems: 'flex-start', gap: 14,
        }}>
          <div style={{
            width: 28, height: 28, borderRadius: 99,
            background: 'rgba(230, 180, 80, 0.16)', color: s.amber,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontWeight: 600, flexShrink: 0,
          }}>!</div>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 14, fontWeight: 500, color: s.amber }}>Position is at risk of liquidation</div>
            <div style={{ fontSize: 12.5, color: 'rgba(230, 180, 80, 0.75)', marginTop: 2 }}>
              ETH would need to drop just 0.8% to liquidate. Add collateral or repay to stay safe.
            </div>
          </div>
          <div style={{ display: 'flex', gap: 8 }}>
            <button style={mAccent(s, { padding: '8px 12px', fontSize: 12.5 })} onClick={() => setTab('add')}>Add collateral</button>
            <button style={mGhost(s, { padding: '8px 12px', fontSize: 12.5 })} onClick={() => setTab('repay')}>Repay</button>
          </div>
        </div>
      )}

      <div style={{ display: 'grid', gridTemplateColumns: '1.3fr 1fr', gap: 20 }}>
        {/* LEFT — position summary */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginBottom: 4 }}>
            <div style={{
              width: 44, height: 44, borderRadius: 99,
              background: s.surface, border: `1px solid ${s.borderHi}`,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontFamily: s.fontMono, fontSize: 16,
            }}>Ξ</div>
            <div style={{ flex: 1 }}>
              <h1 style={{ fontSize: 24, fontWeight: 500, margin: 0, letterSpacing: '-0.02em' }}>ETH position</h1>
              <div style={{ fontSize: 12, color: s.textDim, fontFamily: s.fontMono }}>#1001 · opened Mar 14</div>
            </div>
            <div style={{
              fontSize: 11, padding: '4px 10px', borderRadius: 99,
              background: atRisk ? 'rgba(230, 180, 80, 0.12)' : 'rgba(95, 194, 138, 0.12)',
              color: atRisk ? s.amber : s.green,
              fontFamily: s.fontMono, letterSpacing: '0.04em',
            }}>● {data.healthLabel}</div>
          </div>

          <MCard>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 18 }}>
              <div>
                <MLabel>Collateral</MLabel>
                <div style={{ fontFamily: s.fontMono, fontSize: 26, marginTop: 4, letterSpacing: '-0.02em' }}>{data.col} ETH</div>
                <div style={{ fontFamily: s.fontMono, fontSize: 12, color: s.textMute, marginTop: 2 }}>${data.colUsd.toLocaleString()}</div>
              </div>
              <div>
                <MLabel>Borrowed</MLabel>
                <div style={{ fontFamily: s.fontMono, fontSize: 26, marginTop: 4, letterSpacing: '-0.02em' }}>${data.debt.toLocaleString()}</div>
                <div style={{ fontFamily: s.fontMono, fontSize: 12, color: s.textMute, marginTop: 2 }}>0.50% APR</div>
              </div>
              <div>
                <MLabel>Health factor</MLabel>
                <div style={{
                  fontFamily: s.fontMono, fontSize: 26, marginTop: 4,
                  letterSpacing: '-0.02em',
                  color: atRisk ? s.amber : s.green,
                }}>{data.health}×</div>
              </div>
              <div>
                <MLabel>Liquidation price</MLabel>
                <div style={{ fontFamily: s.fontMono, fontSize: 26, marginTop: 4, letterSpacing: '-0.02em' }}>${data.liqPrice.toLocaleString()}</div>
                <div style={{ fontFamily: s.fontMono, fontSize: 12, color: s.textMute, marginTop: 2 }}>now ${data.current.toLocaleString()}</div>
              </div>
            </div>
          </MCard>

          <MCard>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
              <MLabel>LTV</MLabel>
              <span style={{ fontSize: 12, color: s.text, fontFamily: s.fontMono }}>{data.ltv}% / 80% max</span>
            </div>
            <AnimBar pct={data.ltv} color={atRisk ? s.amber : s.accent} track="rgba(255,255,255,0.05)" height={6} delay={300} />
            <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 6 }}>
              <span style={{ fontSize: 10.5, color: s.textMute, fontFamily: s.fontMono }}>0%</span>
              <span style={{ fontSize: 10.5, color: s.textMute, fontFamily: s.fontMono }}>40%</span>
              <span style={{ fontSize: 10.5, color: s.textMute, fontFamily: s.fontMono }}>80% liq.</span>
            </div>
          </MCard>

          <MCard padding={4}>
            <div style={{ padding: '14px 16px 8px' }}>
              <MLabel>Recent activity</MLabel>
            </div>
            {[
              ['Borrow', '+2,000 XUSD', '6 days ago'],
              ['Deposit', '+1.20 ETH', '12 days ago'],
              ['Open', 'ETH position', 'Mar 14'],
            ].map((row, i, arr) => (
              <div key={i} style={{
                display: 'grid', gridTemplateColumns: '90px 1fr auto',
                gap: 12, padding: '10px 16px', fontSize: 13,
                borderTop: `1px solid ${s.border}`,
              }}>
                <span style={{
                  fontSize: 11, color: s.textDim, fontFamily: s.fontMono,
                  letterSpacing: '0.04em', textTransform: 'uppercase',
                }}>{row[0]}</span>
                <span style={{ fontFamily: s.fontMono, fontSize: 12.5 }}>{row[1]}</span>
                <span style={{ color: s.textMute, fontFamily: s.fontMono, fontSize: 12 }}>{row[2]}</span>
              </div>
            ))}
          </MCard>
        </div>

        {/* RIGHT — tabbed actions */}
        <div>
          <div style={{ display: 'flex', gap: 0, padding: 4, background: s.surface, borderRadius: 8, border: `1px solid ${s.border}`, marginBottom: 12 }}>
            {[
              ['add', 'Add'],
              ['withdraw', 'Withdraw'],
              ['borrow', 'Borrow'],
              ['repay', 'Repay'],
              ['close', 'Close'],
            ].map(([k, l]) => (
              <button key={k} onClick={() => setTab(k)} style={{
                flex: 1, padding: '7px 0', borderRadius: 6,
                fontSize: 12.5, fontWeight: 500, fontFamily: s.fontDisplay,
                border: 'none', cursor: 'pointer',
                background: tab === k ? s.surfaceHi : 'transparent',
                color: tab === k ? s.text : s.textDim,
              }}>{l}</button>
            ))}
          </div>

          {tab === 'add' && <MinimalActionPane label="Add collateral" symbol="ETH" amount="1.00" usd="$3,400" balance="balance 5.20 ETH"
            preview={[['New collateral', '5.20 ETH'], ['New health', atRisk ? '1.31×' : '2.72×'], ['New liq. price', atRisk ? '$2,080' : '$1,870']]}
            cta="Add 1.00 ETH" />}
          {tab === 'withdraw' && <MinimalActionPane label="Withdraw collateral" symbol="ETH" amount="0.50" usd="$1,700" balance="max safe 1.30 ETH"
            preview={[['New collateral', '3.70 ETH'], ['New health', '1.93×'], ['New liq. price', '$2,635']]}
            cta="Withdraw 0.50 ETH" />}
          {tab === 'borrow' && <MinimalActionPane label="Borrow more XUSD" symbol="XUSD" amount="1,000" usd="$1,000" balance="max 4,920 XUSD"
            preview={[['New debt', '7,500 XUSD'], ['New health', '1.90×'], ['New liq. price', '$2,680']]}
            cta="Borrow 1,000 XUSD" />}
          {tab === 'repay' && <MinimalActionPane label="Repay debt" symbol="XUSD" amount="2,000" usd="$2,000" balance="wallet 8,300 XUSD"
            preview={[['New debt', '4,500 XUSD'], ['New health', '3.17×'], ['New liq. price', '$1,605']]}
            cta="Repay 2,000 XUSD" />}
          {tab === 'close' && <MinimalClosePosition data={data} />}
        </div>
      </div>
    </MinimalShell>
  );
};

const MinimalActionPane = ({ label, symbol, amount, usd, balance, preview, cta }) => {
  const s = minimalStyles;
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
      <MCard>
        <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 10 }}>
          <MLabel>{label}</MLabel>
          <div style={{ fontSize: 11.5, color: s.textDim, fontFamily: s.fontMono }}>{balance}</div>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <input defaultValue={amount} style={{
            flex: 1, fontFamily: s.fontMono, fontSize: 32, fontWeight: 400,
            border: 'none', outline: 'none', background: 'transparent', color: s.text,
            letterSpacing: '-0.02em',
          }} />
          <div style={{ padding: '6px 12px', border: `1px solid ${s.borderHi}`, borderRadius: 99, fontSize: 13, fontWeight: 500 }}>{symbol}</div>
        </div>
        <div style={{ fontSize: 12, color: s.textDim, marginTop: 4, fontFamily: s.fontMono }}>≈ {usd}</div>
        <div style={{ display: 'flex', gap: 6, marginTop: 12 }}>
          {['25%', '50%', '75%', 'MAX'].map(p => (
            <span key={p} style={{
              fontSize: 11, padding: '3px 10px', border: `1px solid ${s.border}`, borderRadius: 99,
              color: s.textDim, fontFamily: s.fontMono, cursor: 'pointer',
            }}>{p}</span>
          ))}
        </div>
      </MCard>
      <MCard>
        {preview.map(([k, v], i, arr) => (
          <div key={k} style={{
            display: 'flex', justifyContent: 'space-between',
            padding: '9px 0', fontSize: 13,
            borderBottom: i < arr.length - 1 ? `1px solid ${s.border}` : 'none',
          }}>
            <span style={{ color: s.textDim }}>{k}</span>
            <span style={{ fontFamily: s.fontMono }}>{v}</span>
          </div>
        ))}
      </MCard>
      <button style={mAccent(s, { width: '100%', padding: '13px 0', fontSize: 14 })}>{cta} →</button>
    </div>
  );
};

const MinimalClosePosition = ({ data }) => {
  const s = minimalStyles;
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
      <MCard>
        <MLabel style={{ marginBottom: 10 }}>Close position</MLabel>
        <div style={{ fontSize: 13.5, color: s.textDim, lineHeight: 1.55, marginBottom: 14 }}>
          Repay your full <span style={{ color: s.text, fontFamily: s.fontMono }}>${data.debt.toLocaleString()} XUSD</span> debt and withdraw <span style={{ color: s.text, fontFamily: s.fontMono }}>{data.col} ETH</span> back to your wallet, in one transaction.
        </div>
        <div style={{ borderTop: `1px solid ${s.border}`, paddingTop: 8 }}>
          {[
            ['Repay', `${data.debt.toLocaleString()} XUSD`],
            ['Receive back', `${data.col} ETH`],
            ['Fee', '0 XUSD'],
          ].map(([k, v], i, arr) => (
            <div key={k} style={{
              display: 'flex', justifyContent: 'space-between',
              padding: '8px 0', fontSize: 13,
              borderBottom: i < arr.length - 1 ? `1px solid ${s.border}` : 'none',
            }}>
              <span style={{ color: s.textDim }}>{k}</span>
              <span style={{ fontFamily: s.fontMono }}>{v}</span>
            </div>
          ))}
        </div>
      </MCard>
      <MCard padding={14}>
        <div style={{ fontSize: 12, color: s.textDim, lineHeight: 1.5 }}>
          Closing this position is final. You can always open a new one later.
        </div>
      </MCard>
      <button style={{ ...mAccent(s, { width: '100%', padding: '13px 0', fontSize: 14 }), background: s.red, color: s.bg }}>
        Close position — repay {data.debt.toLocaleString()} XUSD
      </button>
    </div>
  );
};

// ===========================================================
// CONFIRMATION MODAL
// ===========================================================
const MinimalConfirm = () => {
  const s = minimalStyles;
  return (
    <div style={{ background: s.bg, color: s.text, fontFamily: s.fontDisplay, minHeight: '100%', position: 'relative' }}>
      {/* dimmed bg */}
      <div style={{ filter: 'blur(3px) opacity(0.45)', pointerEvents: 'none' }}>
        <MinimalShell active="Borrow">
          <div style={{ height: 600 }} />
        </MinimalShell>
      </div>
      {/* scrim */}
      <div style={{
        position: 'absolute', inset: 0,
        background: 'rgba(5, 6, 9, 0.7)',
        backdropFilter: 'blur(8px)',
        display: 'flex', alignItems: 'flex-start', justifyContent: 'center',
        paddingTop: 80,
      }}>
        <PageFade style={{
          width: 480, background: s.surface,
          border: `1px solid ${s.borderHi}`, borderRadius: 14,
          padding: 28, boxShadow: '0 30px 60px -20px rgba(0,0,0,0.6)',
        }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 22 }}>
            <div>
              <MLabel>Review &amp; confirm</MLabel>
              <h2 style={{ fontSize: 22, fontWeight: 500, margin: '4px 0 0', letterSpacing: '-0.02em' }}>Open ETH position</h2>
            </div>
            <div style={{
              width: 28, height: 28, borderRadius: 6,
              border: `1px solid ${s.border}`, color: s.textDim,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              cursor: 'pointer', fontSize: 14,
            }}>×</div>
          </div>

          {/* From → To */}
          <div style={{
            background: s.bg, border: `1px solid ${s.border}`, borderRadius: 10,
            padding: 16, marginBottom: 16,
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
              <div style={{
                width: 32, height: 32, borderRadius: 99,
                background: s.surfaceHi, border: `1px solid ${s.borderHi}`,
                fontFamily: s.fontMono, fontSize: 14,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}>Ξ</div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 11.5, color: s.textDim, fontFamily: s.fontMono }}>DEPOSIT</div>
                <div style={{ fontSize: 17, fontFamily: s.fontMono, marginTop: 2 }}>4.20 ETH</div>
              </div>
              <div style={{ fontSize: 12, color: s.textDim, fontFamily: s.fontMono }}>$14,280</div>
            </div>
            <div style={{ height: 1, background: s.border, margin: '14px 0', position: 'relative' }}>
              <div style={{
                position: 'absolute', left: '50%', top: '50%', transform: 'translate(-50%, -50%)',
                background: s.surface, padding: '0 8px', color: s.textMute, fontSize: 12,
              }}>↓</div>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
              <div style={{
                width: 32, height: 32, borderRadius: 99,
                background: s.accentDim, color: s.accent,
                fontFamily: s.fontMono, fontSize: 14,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}>$</div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 11.5, color: s.textDim, fontFamily: s.fontMono }}>RECEIVE</div>
                <div style={{ fontSize: 17, fontFamily: s.fontMono, marginTop: 2, color: s.accent }}>6,500 XUSD</div>
              </div>
              <div style={{ fontSize: 12, color: s.textDim, fontFamily: s.fontMono }}>$6,500</div>
            </div>
          </div>

          {/* Details */}
          <div style={{ marginBottom: 16 }}>
            <MLabel style={{ marginBottom: 6 }}>Details</MLabel>
            {[
              ['LTV', '46%'],
              ['Health factor', '2.19×', s.green],
              ['Liquidation price', '$2,320'],
              ['Borrow APR', '0.50%'],
              ['Network fee', '~$2.40'],
            ].map(([k, v, c], i, arr) => (
              <div key={k} style={{
                display: 'flex', justifyContent: 'space-between',
                padding: '8px 0', fontSize: 12.5,
                borderBottom: i < arr.length - 1 ? `1px solid ${s.border}` : 'none',
              }}>
                <span style={{ color: s.textDim }}>{k}</span>
                <span style={{ fontFamily: s.fontMono, color: c || s.text }}>{v}</span>
              </div>
            ))}
          </div>

          <label style={{
            display: 'flex', gap: 10, alignItems: 'flex-start',
            fontSize: 12, color: s.textDim, marginBottom: 18, cursor: 'pointer', lineHeight: 1.5,
          }}>
            <input type="checkbox" defaultChecked style={{ marginTop: 2, accentColor: s.accent }} />
            <span>I understand my collateral can be liquidated if ETH falls below <span style={{ color: s.text, fontFamily: s.fontMono }}>$2,320</span>.</span>
          </label>

          <div style={{ display: 'flex', gap: 8 }}>
            <button style={mGhost(s, { flex: 1 })}>Cancel</button>
            <button style={mAccent(s, { flex: 2, padding: '12px 0' })}>Sign &amp; confirm →</button>
          </div>
        </PageFade>
      </div>
    </div>
  );
};

// ===========================================================
// TX STATUS — pending / confirmed
// ===========================================================
const MinimalTxStatus = ({ phase = 'pending' }) => {
  const s = minimalStyles;
  const steps = [
    { k: 'submit', label: 'Submitted to network' },
    { k: 'mining', label: 'Mining' },
    { k: 'confirmed', label: 'Confirmed' },
  ];
  const stateForStep = (k) => {
    if (phase === 'confirmed') return 'done';
    if (phase === 'pending') return k === 'submit' ? 'done' : k === 'mining' ? 'active' : 'idle';
    return 'idle';
  };

  return (
    <MinimalShell active="Borrow">
      <PageFade style={{ maxWidth: 480, margin: '20px auto 0' }}>
        {/* Big icon */}
        <div style={{ textAlign: 'center', marginBottom: 24 }}>
          <div style={{
            width: 88, height: 88, borderRadius: 99, margin: '0 auto 22px',
            background: phase === 'confirmed' ? s.accentDim : s.surface,
            border: `1px solid ${phase === 'confirmed' ? s.accent : s.borderHi}`,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            position: 'relative',
          }}>
            {phase === 'pending' && (
              <svg width="44" height="44" viewBox="0 0 44 44" style={{ animation: 'mspin 1.4s linear infinite' }}>
                <circle cx="22" cy="22" r="17" fill="none" stroke={s.borderHi} strokeWidth="2" />
                <circle cx="22" cy="22" r="17" fill="none" stroke={s.accent} strokeWidth="2"
                        strokeDasharray="35 110" strokeLinecap="round" />
              </svg>
            )}
            {phase === 'confirmed' && (
              <div style={{ fontSize: 34, color: s.accent, lineHeight: 1 }}>✓</div>
            )}
            <style>{`@keyframes mspin { to { transform: rotate(360deg); } }`}</style>
          </div>
          <h1 style={{ fontSize: 28, fontWeight: 500, margin: 0, letterSpacing: '-0.02em' }}>
            {phase === 'pending' && 'Opening your position…'}
            {phase === 'confirmed' && 'Position opened'}
          </h1>
          <div style={{ fontSize: 14, color: s.textDim, marginTop: 8, lineHeight: 1.5 }}>
            {phase === 'pending' && 'Usually takes 10–30 seconds. You can leave this page; it will keep going.'}
            {phase === 'confirmed' && '6,500 XUSD is now in your wallet.'}
          </div>
        </div>

        <MCard padding={4} style={{ marginBottom: 12 }}>
          {steps.map((step, i) => {
            const st = stateForStep(step.k);
            return (
              <div key={step.k} style={{
                display: 'grid', gridTemplateColumns: '32px 1fr auto',
                gap: 12, padding: '12px 18px', alignItems: 'center',
                borderTop: i > 0 ? `1px solid ${s.border}` : 'none',
                opacity: st === 'idle' ? 0.45 : 1,
              }}>
                <div style={{
                  width: 22, height: 22, borderRadius: 99,
                  border: `1px solid ${st === 'done' ? s.accent : s.borderHi}`,
                  background: st === 'done' ? s.accentDim : 'transparent',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontSize: 11, fontFamily: s.fontMono,
                }}>
                  {st === 'done' && <span style={{ color: s.accent, fontSize: 12 }}>✓</span>}
                  {st === 'active' && <span style={{
                    width: 8, height: 8, borderRadius: 99, background: s.accent,
                    animation: 'mpulse 1.6s ease-in-out infinite',
                  }} />}
                  {st === 'idle' && <span style={{ color: s.textMute }}>{i + 1}</span>}
                </div>
                <div style={{ fontSize: 13.5, color: st === 'idle' ? s.textDim : s.text }}>{step.label}</div>
                <div style={{ fontSize: 11.5, color: s.textDim, fontFamily: s.fontMono }}>
                  {st === 'done' && '✓'}
                  {st === 'active' && 'in progress…'}
                  {st === 'idle' && '—'}
                </div>
              </div>
            );
          })}
          <style>{`@keyframes mpulse { 0%,100% { opacity: 1 } 50% { opacity: 0.3 } }`}</style>
        </MCard>

        <MCard padding={16} style={{ marginBottom: 16 }}>
          {[
            ['Action', 'Open ETH position · borrow 6,500 XUSD'],
            ['Tx hash', '0x84f2…3e1c ↗', s.accent],
            ['Network fee', '$2.40'],
          ].map(([k, v, c], i, arr) => (
            <div key={k} style={{
              display: 'flex', justifyContent: 'space-between',
              padding: '7px 0', fontSize: 12.5,
              borderBottom: i < arr.length - 1 ? `1px solid ${s.border}` : 'none',
            }}>
              <span style={{ color: s.textDim }}>{k}</span>
              <span style={{ fontFamily: s.fontMono, color: c || s.text }}>{v}</span>
            </div>
          ))}
        </MCard>

        <div style={{ display: 'flex', gap: 8 }}>
          {phase === 'pending' && (
            <>
              <button style={mGhost(s, { flex: 1 })}>Keep open</button>
              <button style={mGhost(s, { flex: 1 })}>Back to overview →</button>
            </>
          )}
          {phase === 'confirmed' && (
            <>
              <button style={mGhost(s, { flex: 1 })}>View position</button>
              <button style={mAccent(s, { flex: 1, padding: '11px 0' })}>Back to overview →</button>
            </>
          )}
        </div>
      </PageFade>
    </MinimalShell>
  );
};

Object.assign(window, { MinimalManage, MinimalConfirm, MinimalTxStatus });
