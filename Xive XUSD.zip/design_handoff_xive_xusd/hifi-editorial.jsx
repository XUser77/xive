// Direction C — Editorial / serif. Magazine, premium, generous whitespace.
// Dark warm-paper bg, Instrument Serif display, restrained metrics.

const editorialStyles = {
  bg: '#0d0c0a',
  surface: '#15130f',
  surfaceHi: '#1c1a15',
  border: 'rgba(244, 235, 218, 0.08)',
  borderHi: 'rgba(244, 235, 218, 0.16)',
  text: '#f4ebda',
  textDim: '#9d9281',
  textMute: '#5c5447',
  accent: '#d4a574', // warm gold
  green: '#7fbf9f',
  amber: '#d4a574',
  red: '#d97e6c',
  fontSerif: "'Instrument Serif', Georgia, serif",
  fontSans: "'Geist', system-ui, sans-serif",
  fontMono: "'Geist Mono', monospace",
};

const EditorialDashboard = () => {
  const s = editorialStyles;
  return (
    <div style={{
      background: s.bg, color: s.text,
      fontFamily: s.fontSans, minHeight: '100%',
      display: 'flex', flexDirection: 'column',
    }}>
      <EditorialHeader />
      <PageFade style={{ flex: 1, padding: '32px 56px 40px', maxWidth: 1440, width: '100%', margin: '0 auto' }}>
        <EditorialHero />
        <EditorialMetrics />
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 40, marginTop: 48 }}>
          <EditorialPositions />
          <EditorialSavings />
        </div>
      </PageFade>
    </div>
  );
};

const EditorialHeader = () => {
  const s = editorialStyles;
  return (
    <div style={{
      borderBottom: `1px solid ${s.border}`,
      padding: '20px 56px',
      display: 'flex', justifyContent: 'space-between', alignItems: 'center',
    }}>
      <div style={{ display: 'flex', alignItems: 'baseline', gap: 32 }}>
        <div style={{
          fontFamily: s.fontSerif, fontSize: 30, fontStyle: 'italic',
          letterSpacing: '-0.02em', lineHeight: 1,
        }}>Xive</div>
        <div style={{ display: 'flex', gap: 22, fontSize: 13 }}>
          {['Overview', 'Borrow', 'Earn', 'Markets'].map((it, i) => (
            <span key={it} style={{
              color: i === 0 ? s.text : s.textDim,
              cursor: 'pointer', position: 'relative',
              paddingBottom: 4,
              borderBottom: i === 0 ? `1px solid ${s.accent}` : '1px solid transparent',
            }}>{it}</span>
          ))}
        </div>
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
        <span style={{
          fontFamily: s.fontMono, fontSize: 11.5, color: s.textDim,
          padding: '6px 12px', border: `1px solid ${s.border}`, borderRadius: 99,
        }}>0x84f2…3e1c</span>
        <div style={{
          width: 30, height: 30, borderRadius: 99,
          background: `linear-gradient(135deg, ${s.accent}, #b8745a)`,
        }} />
      </div>
    </div>
  );
};

const EditorialHero = () => {
  const s = editorialStyles;
  return (
    <div style={{ marginBottom: 56, display: 'grid', gridTemplateColumns: '1.3fr 1fr', gap: 56, alignItems: 'flex-end' }}>
      <div>
        <div style={{
          fontSize: 11, color: s.textDim, letterSpacing: '0.18em',
          textTransform: 'uppercase', marginBottom: 18,
          fontFamily: s.fontMono,
        }}>— Volume XII · April 2026</div>
        <h1 style={{
          fontFamily: s.fontSerif, fontSize: 64, lineHeight: 1.0,
          margin: 0, fontWeight: 400, letterSpacing: '-0.02em',
        }}>
          Good evening,<br/>
          <span style={{ fontStyle: 'italic', color: s.accent }}>Alex.</span>
        </h1>
        <div style={{
          fontFamily: s.fontSerif, fontSize: 19, color: s.textDim,
          marginTop: 14, maxWidth: 460, lineHeight: 1.4, fontStyle: 'italic',
        }}>
          Your portfolio is healthy. Three open positions, one savings deposit
          earning quietly in the background.
        </div>
      </div>
      <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end' }}>
        <button style={{
          background: 'transparent', color: s.text,
          border: `1px solid ${s.borderHi}`, borderRadius: 0,
          padding: '12px 22px', fontSize: 13, cursor: 'pointer',
          fontFamily: s.fontSans, letterSpacing: '0.02em',
        }}>Earn XUSD</button>
        <button style={{
          background: s.accent, color: s.bg,
          border: 'none', borderRadius: 0,
          padding: '12px 22px', fontSize: 13, cursor: 'pointer',
          fontFamily: s.fontSans, fontWeight: 500, letterSpacing: '0.02em',
        }}>Borrow ⟶</button>
      </div>
    </div>
  );
};

const EditorialMetrics = () => {
  const s = editorialStyles;
  const m = [
    { l: 'Net worth', v: <TickerUSD to={11180} />, sub: '+$240 last 24h', g: true },
    { l: 'Total borrowed', v: <TickerUSD to={6500} />, sub: '0.5% APR' },
    { l: 'Earning', v: <TickerUSD to={5047} />, sub: '8.4% APY' },
    { l: 'Health factor', v: <><TickerNum to={2.19} decimals={2} />×</>, sub: 'Liquidation $2,320' },
  ];
  return (
    <div style={{
      display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)',
      gap: 0, borderTop: `1px solid ${s.border}`,
      borderBottom: `1px solid ${s.border}`,
    }}>
      {m.map((k, i) => (
        <div key={k.l} style={{
          padding: '28px 24px 28px 0',
          borderRight: i < m.length - 1 ? `1px solid ${s.border}` : 'none',
          paddingLeft: i > 0 ? 24 : 0,
        }}>
          <div style={{
            fontSize: 11, color: s.textDim, letterSpacing: '0.14em',
            textTransform: 'uppercase', fontFamily: s.fontMono, marginBottom: 12,
          }}>{k.l}</div>
          <div style={{
            fontFamily: s.fontSerif, fontSize: 44,
            lineHeight: 1, letterSpacing: '-0.02em',
            color: s.text,
          }}>{k.v}</div>
          <div style={{ fontSize: 12.5, color: s.textDim, marginTop: 8, fontFamily: s.fontMono }}>{k.sub}</div>
        </div>
      ))}
    </div>
  );
};

const EditorialPositions = () => {
  const s = editorialStyles;
  const rows = [
    { token: 'Ether',          sym: 'ETH',   col: '4.20', usd: 14280, debt: 6500, ltv: 46, h: 2.19 },
    { token: 'Wrapped Bitcoin',sym: 'WBTC',  col: '0.18', usd: 12150, debt: 4800, ltv: 39, h: 2.53 },
    { token: 'Lido Staked Ether',sym: 'stETH',col: '2.50', usd: 8520, debt: 5200, ltv: 61, h: 1.64 },
  ];
  return (
    <div>
      <div style={{
        display: 'flex', justifyContent: 'space-between', alignItems: 'baseline',
        marginBottom: 22, paddingBottom: 14,
        borderBottom: `1px solid ${s.border}`,
      }}>
        <h2 style={{
          fontFamily: s.fontSerif, fontSize: 28, fontStyle: 'italic',
          margin: 0, fontWeight: 400,
        }}>Your positions</h2>
        <span style={{ fontSize: 12, color: s.textDim, cursor: 'pointer', fontFamily: s.fontMono }}>VIEW ALL</span>
      </div>

      <div style={{ display: 'flex', flexDirection: 'column' }}>
        {rows.map((r, i) => (
          <StaggerItem key={r.sym} delay={400 + i * 90}>
            <div style={{
              padding: '22px 0',
              borderBottom: i < rows.length - 1 ? `1px solid ${s.border}` : 'none',
              display: 'grid', gridTemplateColumns: '1.3fr 1fr 1fr 100px',
              gap: 20, alignItems: 'center',
              cursor: 'pointer',
            }}>
              <div>
                <div style={{
                  fontSize: 11, color: s.textDim, fontFamily: s.fontMono,
                  letterSpacing: '0.06em', textTransform: 'uppercase',
                }}>Position #100{i+1}</div>
                <div style={{
                  fontFamily: s.fontSerif, fontSize: 26, marginTop: 2,
                  letterSpacing: '-0.01em',
                }}>{r.token}</div>
              </div>
              <div>
                <div style={{ fontSize: 11, color: s.textDim, fontFamily: s.fontMono, letterSpacing: '0.06em' }}>COLLATERAL</div>
                <div style={{ fontFamily: s.fontMono, fontSize: 17, marginTop: 4 }}>{r.col} {r.sym}</div>
                <div style={{ fontFamily: s.fontMono, fontSize: 11, color: s.textMute, marginTop: 1 }}>${r.usd.toLocaleString()}</div>
              </div>
              <div>
                <div style={{ fontSize: 11, color: s.textDim, fontFamily: s.fontMono, letterSpacing: '0.06em' }}>BORROWED</div>
                <div style={{ fontFamily: s.fontMono, fontSize: 17, marginTop: 4 }}>${r.debt.toLocaleString()}</div>
                <div style={{ marginTop: 8 }}>
                  <AnimBar pct={r.ltv} color={r.ltv > 60 ? s.amber : s.accent} track={s.surface} height={2} radius={0} delay={500 + i * 100} />
                </div>
              </div>
              <div style={{ textAlign: 'right' }}>
                <div style={{
                  fontFamily: s.fontSerif, fontSize: 26,
                  fontStyle: 'italic',
                  color: r.h < 1.8 ? s.amber : s.green,
                }}>{r.h}<span style={{ fontFamily: s.fontMono, fontSize: 14, marginLeft: 2 }}>×</span></div>
                <div style={{ fontSize: 11, color: s.textDim, fontFamily: s.fontMono, letterSpacing: '0.06em' }}>HEALTH</div>
              </div>
            </div>
          </StaggerItem>
        ))}
      </div>
    </div>
  );
};

const EditorialSavings = () => {
  const s = editorialStyles;
  return (
    <div>
      <div style={{
        display: 'flex', justifyContent: 'space-between', alignItems: 'baseline',
        marginBottom: 22, paddingBottom: 14,
        borderBottom: `1px solid ${s.border}`,
      }}>
        <h2 style={{
          fontFamily: s.fontSerif, fontSize: 28, fontStyle: 'italic',
          margin: 0, fontWeight: 400,
        }}>The savings vault</h2>
        <span style={{ fontSize: 12, color: s.textDim, fontFamily: s.fontMono }}>LIVE</span>
      </div>

      {/* Big serif APY */}
      <div style={{ marginBottom: 28 }}>
        <div style={{ fontSize: 11, color: s.textDim, fontFamily: s.fontMono, letterSpacing: '0.14em', textTransform: 'uppercase' }}>Current yield</div>
        <div style={{
          fontFamily: s.fontSerif, fontSize: 96, lineHeight: 1,
          letterSpacing: '-0.03em', marginTop: 6,
          color: s.accent,
        }}>
          <TickerNum to={8.4} decimals={1} />
          <span style={{ fontStyle: 'italic', fontSize: 64 }}>%</span>
        </div>
        <div style={{ fontSize: 13, color: s.textDim, marginTop: 6, fontFamily: s.fontSerif, fontStyle: 'italic' }}>
          A thirty-day average, paid from positions liquidated by the protocol.
        </div>
      </div>

      <div style={{
        padding: '22px 0',
        borderTop: `1px solid ${s.border}`,
        display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20,
      }}>
        <div>
          <div style={{ fontSize: 11, color: s.textDim, fontFamily: s.fontMono, letterSpacing: '0.06em', textTransform: 'uppercase' }}>Your deposit</div>
          <div style={{ fontFamily: s.fontSerif, fontSize: 32, marginTop: 6 }}>$5,047.20</div>
          <div style={{ fontSize: 11.5, color: s.textMute, fontFamily: s.fontMono, marginTop: 2 }}>since Mar 18</div>
        </div>
        <div>
          <div style={{ fontSize: 11, color: s.textDim, fontFamily: s.fontMono, letterSpacing: '0.06em', textTransform: 'uppercase' }}>Yield earned</div>
          <div style={{ fontFamily: s.fontSerif, fontSize: 32, marginTop: 6, color: s.green, fontStyle: 'italic' }}>+$47.20</div>
          <div style={{ fontSize: 11.5, color: s.textMute, fontFamily: s.fontMono, marginTop: 2 }}>~$1.50/day</div>
        </div>
      </div>

      <button style={{
        background: 'transparent', color: s.text,
        border: `1px solid ${s.borderHi}`, borderRadius: 0,
        padding: '14px 0', width: '100%', fontSize: 13, cursor: 'pointer',
        fontFamily: s.fontSans, letterSpacing: '0.04em', marginTop: 8,
      }}>Manage deposit ⟶</button>
    </div>
  );
};

Object.assign(window, { EditorialDashboard });
