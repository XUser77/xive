// XIVE — Main / landing page (Direction A palette)
// Sections: nav · hero · what is XUSD · how it works · footer

const MinimalMain = () => {
  const s = minimalStyles;
  return (
    <div style={{
      background: s.bg, color: s.text,
      fontFamily: s.fontDisplay,
      minHeight: '100%', display: 'flex', flexDirection: 'column',
    }}>
      <MainNav />
      <PageFade style={{ flex: 1 }}>
        <MainHero />
        <MainWhat />
        <MainHow />
        <MainFooter />
      </PageFade>
    </div>
  );
};

// ===== nav =====
const MainNav = () => {
  const s = minimalStyles;
  const links = ['Docs', 'Markets', 'Stats', 'Blog'];
  return (
    <div style={{
      height: 64, borderBottom: `1px solid ${s.border}`,
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      padding: '0 48px', position: 'sticky', top: 0,
      background: 'rgba(11, 13, 16, 0.85)', backdropFilter: 'blur(12px)',
      zIndex: 10,
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
        <div style={{ fontSize: 22, fontWeight: 600, letterSpacing: '-0.02em' }}>XIVE</div>
        <div style={{
          fontSize: 10, padding: '2px 6px', borderRadius: 4,
          background: s.accentDim, color: s.accent,
          fontFamily: s.fontMono, letterSpacing: '0.05em',
        }}>BETA</div>
      </div>
      <div style={{ display: 'flex', gap: 28, fontSize: 13.5, color: s.textDim }}>
        {links.map(l => (
          <span key={l} style={{ cursor: 'pointer' }}>{l}</span>
        ))}
      </div>
      <div style={{ display: 'flex', gap: 10 }}>
        <button style={btnGhost(s, { padding: '9px 16px', fontSize: 13 })}>Connect wallet</button>
        <button style={btnPrimary(s, { padding: '9px 18px', fontSize: 13 })}>Launch app →</button>
      </div>
    </div>
  );
};

// ===== hero =====
const MainHero = () => {
  const s = minimalStyles;
  return (
    <div style={{
      position: 'relative', overflow: 'hidden',
      padding: '120px 48px 100px',
    }}>
      {/* halo */}
      <div style={{
        position: 'absolute', top: -200, left: '50%', transform: 'translateX(-50%)',
        width: 900, height: 600, borderRadius: '50%',
        background: s.accentDim, filter: 'blur(140px)', opacity: 0.6, pointerEvents: 'none',
      }} />
      {/* faint grid */}
      <div style={{
        position: 'absolute', inset: 0, opacity: 0.4,
        backgroundImage: `linear-gradient(${s.border} 1px, transparent 1px), linear-gradient(90deg, ${s.border} 1px, transparent 1px)`,
        backgroundSize: '64px 64px',
        maskImage: 'radial-gradient(ellipse at 50% 30%, black 0%, transparent 70%)',
        WebkitMaskImage: 'radial-gradient(ellipse at 50% 30%, black 0%, transparent 70%)',
        pointerEvents: 'none',
      }} />

      <div style={{ position: 'relative', maxWidth: 1100, margin: '0 auto', textAlign: 'center' }}>
        <div style={{
          display: 'inline-flex', alignItems: 'center', gap: 8,
          padding: '6px 12px', borderRadius: 99,
          border: `1px solid ${s.border}`,
          fontSize: 12, color: s.textDim, fontFamily: s.fontMono,
          letterSpacing: '0.04em',
          marginBottom: 32,
        }}>
          <span style={{ width: 6, height: 6, borderRadius: 99, background: s.green, boxShadow: `0 0 0 3px ${s.green}22` }} />
          Live on mainnet · v0.4.2
        </div>

        <h1 style={{
          fontSize: 84, fontWeight: 500, lineHeight: 1.02,
          letterSpacing: '-0.035em', margin: 0,
        }}>
          A stablecoin you<br/>
          <span style={{ color: s.accent }}>mint yourself.</span>
        </h1>

        <div style={{
          fontSize: 18, color: s.textDim, marginTop: 26,
          lineHeight: 1.5, maxWidth: 580, margin: '26px auto 0',
        }}>
          Deposit ETH or wBTC, mint XUSD against it at up to 80% LTV.
          Keep your upside, spend dollars, repay anytime — no fixed term, no middlemen.
        </div>

        <div style={{ display: 'flex', gap: 12, justifyContent: 'center', marginTop: 36 }}>
          <button style={btnPrimary(s, { padding: '13px 24px', fontSize: 14 })}>Launch app →</button>
          <button style={btnGhost(s, { padding: '13px 24px', fontSize: 14 })}>Read the docs</button>
        </div>

        {/* live stat strip */}
        <div style={{
          marginTop: 80, display: 'grid',
          gridTemplateColumns: 'repeat(4, 1fr)',
          gap: 0,
          background: s.surface, border: `1px solid ${s.border}`,
          borderRadius: 12, overflow: 'hidden', maxWidth: 880, margin: '80px auto 0',
        }}>
          {[
            ['$24.6M', 'Total value locked'],
            ['$9.2M', 'XUSD outstanding'],
            ['8.4%', 'Savings APY'],
            ['142', 'Active positions'],
          ].map(([v, k], i, arr) => (
            <div key={k} style={{
              padding: '20px 22px', textAlign: 'left',
              borderRight: i < arr.length - 1 ? `1px solid ${s.border}` : 'none',
            }}>
              <div style={{ fontSize: 26, fontFamily: s.fontMono, fontWeight: 400, letterSpacing: '-0.02em' }}>{v}</div>
              <div style={{
                fontSize: 11, color: s.textDim, fontFamily: s.fontMono,
                letterSpacing: '0.06em', textTransform: 'uppercase', marginTop: 4,
              }}>{k}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

// ===== what is XUSD =====
const MainWhat = () => {
  const s = minimalStyles;
  return (
    <div style={{ padding: '100px 48px', borderTop: `1px solid ${s.border}` }}>
      <div style={{ maxWidth: 1100, margin: '0 auto' }}>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1.4fr', gap: 80, alignItems: 'start' }}>
          {/* left: label + heading */}
          <div style={{ position: 'sticky', top: 100 }}>
            <div style={{
              fontSize: 11.5, color: s.textDim, fontFamily: s.fontMono,
              letterSpacing: '0.08em', textTransform: 'uppercase', marginBottom: 16,
            }}>What is XUSD</div>
            <h2 style={{
              fontSize: 44, fontWeight: 500, margin: 0,
              letterSpacing: '-0.025em', lineHeight: 1.1,
            }}>
              A dollar, fully backed by your collateral.
            </h2>
            <div style={{ fontSize: 15, color: s.textDim, marginTop: 18, lineHeight: 1.6 }}>
              XUSD is a decentralized stablecoin you mint by locking crypto.
              No bank, no issuer — just code and overcollateralized math.
            </div>
          </div>

          {/* right: facts list */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 0 }}>
            {[
              {
                k: '01',
                t: 'Overcollateralized',
                d: 'Every XUSD in circulation is backed by more than $1 of crypto collateral, so the peg holds even if markets move.',
              },
              {
                k: '02',
                t: 'Non-custodial',
                d: 'Your collateral lives in a smart contract — not on a balance sheet. You control the keys; you control the position.',
              },
              {
                k: '03',
                t: 'No fixed term',
                d: 'Mint XUSD when you need dollars; repay whenever. There is no maturity date, no rolling, no liquidation deadline.',
              },
              {
                k: '04',
                t: 'Transparent on-chain',
                d: 'Total supply, every position\'s health, and the savings vault\'s reserves are public and verifiable in real time.',
              },
            ].map((f, i, arr) => (
              <div key={f.k} style={{
                padding: '24px 0',
                borderTop: `1px solid ${s.border}`,
                borderBottom: i === arr.length - 1 ? `1px solid ${s.border}` : 'none',
                display: 'grid', gridTemplateColumns: '60px 1fr', gap: 24,
              }}>
                <div style={{
                  fontSize: 12, color: s.accent, fontFamily: s.fontMono,
                  letterSpacing: '0.06em',
                }}>{f.k}</div>
                <div>
                  <div style={{ fontSize: 18, fontWeight: 500, letterSpacing: '-0.01em' }}>{f.t}</div>
                  <div style={{ fontSize: 14, color: s.textDim, marginTop: 6, lineHeight: 1.55 }}>{f.d}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

// ===== how it works =====
const MainHow = () => {
  const s = minimalStyles;
  const steps = [
    {
      n: '01',
      t: 'Deposit collateral',
      d: 'Lock ETH or wBTC in a position. Your asset stays yours — you keep the upside if it appreciates.',
      vis: 'deposit',
    },
    {
      n: '02',
      t: 'Mint XUSD',
      d: 'Borrow up to 80% of your collateral\'s value as XUSD. Spend it, swap it, or deposit it for yield.',
      vis: 'mint',
    },
    {
      n: '03',
      t: 'Repay anytime',
      d: 'Pay back XUSD whenever you want and unlock your collateral. No fixed term, no penalties.',
      vis: 'repay',
    },
  ];
  return (
    <div style={{ padding: '100px 48px', borderTop: `1px solid ${s.border}` }}>
      <div style={{ maxWidth: 1100, margin: '0 auto' }}>
        <div style={{ textAlign: 'center', marginBottom: 64 }}>
          <div style={{
            fontSize: 11.5, color: s.textDim, fontFamily: s.fontMono,
            letterSpacing: '0.08em', textTransform: 'uppercase', marginBottom: 14,
          }}>How it works</div>
          <h2 style={{
            fontSize: 44, fontWeight: 500, margin: 0,
            letterSpacing: '-0.025em', lineHeight: 1.1,
          }}>
            Three steps, on-chain.
          </h2>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16 }}>
          {steps.map((step, i) => (
            <div key={step.n} style={{
              background: s.surface, border: `1px solid ${s.border}`,
              borderRadius: 12, padding: 28,
              display: 'flex', flexDirection: 'column', minHeight: 320,
              position: 'relative', overflow: 'hidden',
            }}>
              <div style={{
                fontSize: 11, color: s.accent, fontFamily: s.fontMono,
                letterSpacing: '0.08em', marginBottom: 18,
              }}>STEP {step.n}</div>

              {/* mini illustration */}
              <div style={{
                height: 120, marginBottom: 20,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                position: 'relative',
              }}>
                <HowVisual kind={step.vis} />
              </div>

              <div style={{ fontSize: 20, fontWeight: 500, letterSpacing: '-0.01em' }}>{step.t}</div>
              <div style={{ fontSize: 14, color: s.textDim, marginTop: 8, lineHeight: 1.55 }}>{step.d}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

// little SVG-ish illustrations using styled divs (no icon-slop)
const HowVisual = ({ kind }) => {
  const s = minimalStyles;
  if (kind === 'deposit') {
    return (
      <div style={{ position: 'relative', width: 180, height: 100 }}>
        <div style={{
          position: 'absolute', top: 0, left: '50%', transform: 'translateX(-50%)',
          width: 56, height: 56, borderRadius: 14,
          background: s.accentDim, color: s.accent,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontSize: 22, border: `1px solid ${s.borderHi}`,
        }}>Ξ</div>
        <div style={{
          position: 'absolute', bottom: 0, left: '50%', transform: 'translateX(-50%)',
          width: 120, height: 4, borderRadius: 2,
          background: `linear-gradient(90deg, transparent, ${s.accent}, transparent)`,
        }} />
        <div style={{
          position: 'absolute', top: 60, left: '50%', transform: 'translateX(-50%)',
          fontSize: 18, color: s.accent, fontFamily: 'monospace',
        }}>↓</div>
      </div>
    );
  }
  if (kind === 'mint') {
    return (
      <div style={{
        display: 'flex', alignItems: 'center', gap: 14,
      }}>
        <div style={{
          width: 50, height: 50, borderRadius: 12,
          background: s.surfaceHi, border: `1px solid ${s.borderHi}`,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontSize: 18, color: s.text,
        }}>Ξ</div>
        <div style={{
          width: 50, height: 1, background: s.borderHi, position: 'relative',
        }}>
          <span style={{
            position: 'absolute', top: -7, right: -2, color: s.accent, fontSize: 14,
          }}>→</span>
        </div>
        <div style={{
          width: 64, height: 64, borderRadius: 99,
          background: s.accent, color: s.bg,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontSize: 22, fontWeight: 600, letterSpacing: '-0.02em',
        }}>$</div>
      </div>
    );
  }
  // repay
  return (
    <div style={{ position: 'relative', width: 180, height: 100 }}>
      <div style={{
        position: 'absolute', inset: 0,
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        padding: '0 8px',
      }}>
        <div style={{
          width: 50, height: 50, borderRadius: 99,
          background: s.accent, color: s.bg,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontSize: 18, fontWeight: 600,
        }}>$</div>
        <div style={{
          fontSize: 11, color: s.textDim, fontFamily: 'monospace',
          letterSpacing: '0.05em',
        }}>REPAY</div>
        <div style={{
          width: 50, height: 50, borderRadius: 12,
          background: s.surfaceHi, border: `1px solid ${s.borderHi}`,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontSize: 18, color: s.text,
        }}>Ξ</div>
      </div>
      <div style={{
        position: 'absolute', top: 24, left: 50, right: 50, height: 1,
        background: s.borderHi,
      }} />
    </div>
  );
};

// ===== footer =====
const MainFooter = () => {
  const s = minimalStyles;
  const cols = [
    {
      h: 'Product',
      links: ['Borrow', 'Earn', 'Markets', 'Launch app'],
    },
    {
      h: 'Resources',
      links: ['Docs', 'Whitepaper', 'Audits', 'Brand kit'],
    },
    {
      h: 'Community',
      links: ['Twitter', 'Discord', 'Mirror', 'Github'],
    },
    {
      h: 'Legal',
      links: ['Terms', 'Privacy', 'Risk disclosure'],
    },
  ];
  return (
    <div style={{
      borderTop: `1px solid ${s.border}`,
      padding: '64px 48px 36px',
      background: s.bg,
    }}>
      <div style={{ maxWidth: 1100, margin: '0 auto' }}>
        <div style={{
          display: 'grid', gridTemplateColumns: '1.4fr repeat(4, 1fr)', gap: 32,
          paddingBottom: 48,
        }}>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <div style={{ fontSize: 22, fontWeight: 600, letterSpacing: '-0.02em' }}>XIVE</div>
              <div style={{
                fontSize: 10, padding: '2px 6px', borderRadius: 4,
                background: s.accentDim, color: s.accent,
                fontFamily: s.fontMono, letterSpacing: '0.05em',
              }}>BETA</div>
            </div>
            <div style={{ fontSize: 13, color: s.textDim, marginTop: 12, lineHeight: 1.55, maxWidth: 240 }}>
              A stablecoin protocol for people who own crypto and want dollars.
            </div>
          </div>
          {cols.map(c => (
            <div key={c.h}>
              <div style={{
                fontSize: 11.5, color: s.textDim, fontFamily: s.fontMono,
                letterSpacing: '0.06em', textTransform: 'uppercase', marginBottom: 14,
              }}>{c.h}</div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                {c.links.map(l => (
                  <span key={l} style={{ fontSize: 13.5, color: s.text, cursor: 'pointer' }}>{l}</span>
                ))}
              </div>
            </div>
          ))}
        </div>

        <div style={{
          paddingTop: 24, borderTop: `1px solid ${s.border}`,
          display: 'flex', justifyContent: 'space-between', alignItems: 'center',
          fontSize: 12, color: s.textMute, fontFamily: s.fontMono,
        }}>
          <span>© 2024 XIVE Labs · open-source under MIT</span>
          <span style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <span style={{ width: 6, height: 6, borderRadius: 99, background: s.green }} />
            All systems normal
          </span>
        </div>
      </div>
    </div>
  );
};

Object.assign(window, { MinimalMain });
