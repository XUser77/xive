# Handoff: XIVE — XUSD stablecoin protocol UI

## Overview

XIVE is a decentralized, overcollateralized stablecoin protocol. Users lock crypto collateral (ETH, wBTC) to mint **XUSD** (the protocol's stablecoin) at up to 80% LTV. A separate **savings vault** lets XUSD holders earn yield by absorbing liquidations of unhealthy positions at a discount.

This handoff covers the full hi-fi screen set:

- **Main / landing page** (public, marketing)
- **Dashboard — disconnected** (wallet not connected; only public protocol info shown)
- **Dashboard — connected (Overview)** (user's positions, KPIs, recent activity, accepted collaterals)
- **Borrow flow** (open a new position)
- **Earn flow** (deposit XUSD into the savings vault)
- **Manage position** (healthy and at-risk variants — Add / Withdraw / Borrow / Repay / Close tabs)
- **Confirm & transaction status** (review modal, pending, confirmed)
- **Onboarding** (Connect wallet, Empty dashboard)

Two reference directions (`B — DeFi trader`, `C — Editorial / serif`) are included for context only — **Direction A (minimal & calm) is the locked direction to build**.

---

## About the design files

The files in this bundle are **design references created in HTML**. They are React + inline JSX prototypes loaded through Babel-standalone in the browser, hosted inside a custom `<DesignCanvas>` pan/zoom presentation shell. **They are not production code to copy directly.**

The task is to **recreate these designs in the target codebase's environment** using its established patterns, libraries, and component primitives. If no codebase exists yet, prefer **Next.js (App Router) + TypeScript + Tailwind CSS** with a wallet library appropriate for the chain (e.g. wagmi + viem + RainbowKit / ConnectKit for EVM). For animations, **Framer Motion** is a good match for the staggered fade-ins, ticker counters, and bar fills used throughout.

The HTML prototypes optimize for fast iteration, not architecture: shared style objects, no routing, no real wallet hooks, mocked data inline. **Discard those decisions** when porting — pick proper components, real state management, real data fetching, real routing.

---

## Fidelity

**High-fidelity (hifi).** Final colors, typography, spacing, copy, hover/active states, and micro-interactions are all decided. Recreate pixel-perfectly using the codebase's component system. The included `hifi-shared.jsx` file contains the canonical animation primitives (`PageFade`, `StaggerItem`, `TickerNum`, `TickerUSD`, `AnimBar`, `LiveDot`) — port these to Framer Motion equivalents.

---

## Vocabulary — IMPORTANT

These two terms are easy to confuse. Get them right in code, copy, and URLs:

| Term | Meaning |
|---|---|
| **Position** | A user's individual borrow: collateral deposited + XUSD debt minted against it. Each user can have many positions, one per collateral type. Has a health factor, LTV, liquidation price. Plural: "positions". |
| **Vault** | The single, protocol-wide **XUSD savings vault**. Users deposit XUSD into it to earn yield. The vault absorbs liquidations of unhealthy positions at a discount; that discount + liquidation fees are the yield source. Singular and unique. |

In the code, use names like `Position`, `PositionRow`, `OpenPositionFlow`, `ManagePosition`, `closePosition()` for the borrow side, and `SavingsVault`, `vaultDeposit`, `vaultApy`, `depositToVault()` for the lender side. Never call a borrow position a "vault".

---

## Visual system (Direction A)

### Color tokens

```ts
// from hifi-minimal.jsx — port these to your token system
const colors = {
  bg:        '#0b0d10',                   // page background
  surface:   '#13161b',                   // cards, panels
  surfaceHi: '#181c22',                   // hover, raised surface
  border:    'rgba(255,255,255,0.06)',
  borderHi:  'rgba(255,255,255,0.10)',

  text:      '#e9ecef',                   // primary text
  textDim:   '#8a9099',                   // secondary text
  textMute:  '#5b6168',                   // tertiary / mono labels

  accent:    '#7c9bff',                   // cool indigo — links, primary actions, highlights
  accentDim: 'rgba(124, 155, 255, 0.12)', // accent halo / tint backgrounds

  green:     '#5fc28a',                   // healthy, positive deltas, live dot
  amber:     '#e6b450',                   // warning, at-risk
  red:       '#ec6f6f',                   // danger, liquidation, negative
};
```

The palette is deliberately restrained — almost monochromatic with one indigo accent. **Resist adding more hues.** Status colors only appear in tiny doses (a 6px dot, one number, a 3-4px progress bar fill).

### Typography

| Role | Stack |
|---|---|
| Display / UI | `'Geist', system-ui, sans-serif` |
| Mono (numbers, addresses, labels) | `'Geist Mono', 'JetBrains Mono', monospace` |

Loaded from Google Fonts: `Geist:wght@300;400;500;600;700` and `Geist Mono:wght@400;500;600`.

**Type scale** (used throughout):

| px  | weight | letter-spacing | use |
|----:|:------:|:--------------:|---|
|  84 | 500    | -0.035em       | hero headline (Main page only) |
|  44 | 500    | -0.025em       | section headlines (Main page) |
|  30 | 500    | -0.025em       | page H1 (Dashboard, Borrow, Earn, Manage) |
|  28 | 500    | -0.02em        | KPI value |
|  22 | 500    | -0.02em        | card H2, modal title |
|  18 | 500    | -0.01em        | medium emphasis (collateral names, step titles) |
|  14 | 500    | normal          | body, table cells, button text |
|  13 | 400    | normal          | secondary body |
|  12 | 400    | normal          | helper text, small labels |
|  11.5 | 400  | 0.04–0.08em    | uppercase mono labels (`OVERVIEW`, `MAX LTV`, etc.) |

All numerics, addresses, percentages, USD amounts, hashes, and timestamps render in **Geist Mono**. All small uppercase labels use Geist Mono with `letterSpacing: 0.04–0.08em` and `textTransform: uppercase`.

### Spacing

Multiples of 2/4: `4, 6, 8, 10, 12, 14, 16, 18, 20, 22, 24, 28, 32, 40, 48, 64, 80, 100`. Cards use `padding: 20–28px`. Page gutter is `28–32px`. Grid gaps are `16–20px` for content, `12px` for inline tight groups.

### Borders & radius

- Cards: `border: 1px solid rgba(255,255,255,0.06)`, `border-radius: 10–12px`.
- Buttons: `border-radius: 6px`.
- Avatars / coin glyphs: `border-radius: 99px` (circular).
- Pills / badges: `border-radius: 99px` for full pills, `4px` for square tags.

No drop shadows on cards. Depth is communicated by the surface gradient (`bg → surface → surfaceHi`) and 1px borders only.

### Buttons

```ts
// btnPrimary — light pill on dark
{
  background: '#e9ecef',  // text color, not accent
  color: '#0b0d10',
  border: 'none',
  padding: '8px 14px',
  fontSize: 13,
  fontWeight: 500,
  borderRadius: 6,
  letterSpacing: '-0.01em',
}

// btnGhost — outline only
{
  background: 'transparent',
  color: '#e9ecef',
  border: '1px solid rgba(255,255,255,0.10)',
  padding: '8px 14px',
  fontSize: 13,
  fontWeight: 500,
  borderRadius: 6,
}
```

Primary CTA uses **white text-color background**, not the indigo accent. Indigo is reserved for inline highlights, links, and the "accent" callout in headlines (e.g. `mint yourself.` is colored, the rest of the headline isn't).

### Animations

Implemented in `hifi-shared.jsx`. Behaviors to preserve when porting:

- **`PageFade`** — page wrapper. Fades in (`opacity 0 → 1`) and slides up 8px over **400ms** with `cubic-bezier(0.16, 1, 0.3, 1)` on mount.
- **`StaggerItem`** — list-row wrapper. Same fade-up, staggered with a per-item delay (`200ms + i * 80ms` typical for table rows).
- **`TickerNum` / `TickerUSD`** — counts up to its target value over **900ms** with ease-out, using `requestAnimationFrame`.
- **`AnimBar`** — bar fills from `width: 0%` to its target width over **600ms** ease-out, with an optional delay.
- **`LiveDot`** — green dot with a subtle pulsing glow.

Use Framer Motion's `motion.div`, `useSpring`, and `AnimatePresence` to recreate these. Hover transitions on rows and buttons use `transition: all 150–160ms ease`.

---

## Screens

The canvas (`XIVE Hi-Fi Dashboard.html`) opens in `design-canvas.jsx` — a pan/zoom artboard grid. Each artboard is a fixed-size `<DCArtboard width height>` containing one full-screen mock. Browse by panning, or click any artboard to open it fullscreen.

Sections, top → bottom:

### 1. Landing & disconnected
- **Main — landing page** (1440 × 2400) — public marketing page. `MinimalMain` in `hifi-main.jsx`.
- **Dashboard — disconnected** (1440 × 900) — connected app shell with no user data. `MinimalDashboard connected={false}` in `hifi-minimal.jsx`.

### 2. Direction A — dashboard & primary flows
- **Overview** (1440 × 900) — connected dashboard. `MinimalDashboard` in `hifi-minimal.jsx`.
- **Borrow — open position** (1440 × 900) — `MinimalBorrow` in `hifi-a-flows-1.jsx`.
- **Earn — savings vault** (1440 × 900) — `MinimalEarn` in `hifi-a-flows-1.jsx`.

### 3. Manage position
- **Manage — healthy** (1440 × 950) — `MinimalManage` in `hifi-a-flows-2.jsx`.
- **Manage — at risk** (1440 × 1000) — `MinimalManage atRisk` in `hifi-a-flows-2.jsx`.

### 4. Confirm & transaction status
- **Confirmation modal** (1440 × 900) — `MinimalConfirm` in `hifi-a-flows-2.jsx`.
- **Tx — pending** (1440 × 900) — `MinimalTxStatus phase="pending"`.
- **Tx — confirmed** (1440 × 900) — `MinimalTxStatus phase="confirmed"`.

### 5. Onboarding & empty
- **Connect wallet** (1440 × 900) — `MinimalConnect` in `hifi-a-onboarding.jsx`.
- **Empty dashboard** (1440 × 900) — `MinimalEmptyDash` (wallet connected, no positions yet).

Reference-only sections (Direction B, Direction C) are not in scope.

---

## Screen-by-screen detail

### Main — landing page

**File:** `hifi-main.jsx` → `MinimalMain`. **Width:** 1440. **Height:** ~2400 (scrolls).

Sections, top → bottom:

1. **Sticky nav** (`MainNav`, 64px tall, `padding: 0 48px`):
   - Left: `XIVE` logo (22px, weight 600, `-0.02em`) + `BETA` pill (10px, indigo tint background).
   - Center: links — `Docs`, `Markets`, `Stats`, `Blog`. 13.5px, `textDim`, gap 28px.
   - Right: `Connect wallet` ghost button + `Launch app →` primary button. Gap 10px.
   - Background: `rgba(11, 13, 16, 0.85)` with `backdropFilter: blur(12px)`. Bottom border 1px.

2. **Hero** (`MainHero`, `padding: 120px 48px 100px`):
   - Decorative: large indigo halo (`width: 900, height: 600`, `filter: blur(140px)`, `opacity: 0.6`) at `top: -200, left: 50%`. A faint 64px grid below it, masked with a radial gradient so it fades to transparent.
   - Live status pill: rounded `border 1px`, contains a green pulsing dot + `Live on mainnet · v0.4.2` (mono, 12px).
   - Headline: 84px / weight 500 / `-0.035em`. Two lines: `A stablecoin you` + `mint yourself.` — the second line is `accent` colored.
   - Subhead: 18px `textDim`, max-width 580, centered. Copy: "Deposit ETH or wBTC, mint XUSD against it at up to 80% LTV. Keep your upside, spend dollars, repay anytime — no fixed term, no middlemen."
   - CTAs: `Launch app →` (primary, padding 13px 24px) + `Read the docs` (ghost). Gap 12px.
   - **Live stat strip** below: 4-cell grid in a `surface` card, max-width 880. Each cell: 26px mono number + 11px uppercase mono label. Cells: `$24.6M / Total value locked`, `$9.2M / XUSD outstanding`, `8.4% / Savings APY`, `142 / Active positions`. Cells separated by 1px right borders (no border on last).

3. **What is XUSD** (`MainWhat`, `padding: 100px 48px`, top border):
   - Two columns (`1fr 1.4fr`, gap 80, max-width 1100).
   - Left (sticky at `top: 100`): mono kicker `WHAT IS XUSD`, headline 44px ("A dollar, fully backed by your collateral."), subhead 15px.
   - Right: 4 facts. Each: a 2-col grid (`60px 1fr`) with a mono accent number (`01`–`04`) on the left and a 18px title + 14px description on the right. Top border on each, bottom border on the last.
   - Facts: Overcollateralized · Non-custodial · No fixed term · Transparent on-chain.

4. **How it works** (`MainHow`, `padding: 100px 48px`, top border):
   - Centered intro: mono kicker `HOW IT WORKS`, headline 44px ("Three steps, on-chain."). Margin-bottom 64.
   - 3-card grid (`repeat(3, 1fr)`, gap 16). Each card: `surface` background, 1px border, `border-radius: 12`, padding 28, min-height 320.
   - Card content: `STEP 01` mono accent label → 120px-tall illustration → 20px title → 14px description.
   - Steps:
     1. **Deposit collateral** — illustration: a 56px rounded indigo-tinted square with `Ξ` glyph, an `↓` arrow below, then a horizontal indigo gradient bar.
     2. **Mint XUSD** — illustration: ETH glyph square → arrow → 64px indigo circle with `$`.
     3. **Repay anytime** — illustration: `$` circle ↔ `Ξ` square with the word `REPAY` between them on a horizontal line.

5. **Footer** (`MainFooter`, `padding: 64px 48px 36px`, top border):
   - 5-col grid (`1.4fr repeat(4, 1fr)`, gap 32, max-width 1100, padding-bottom 48).
   - Col 1: XIVE+BETA logo, 240px-wide tagline ("A stablecoin protocol for people who own crypto and want dollars.").
   - Cols 2–5: link columns — `Product` (Borrow, Earn, Markets, Launch app), `Resources` (Docs, Whitepaper, Audits, Brand kit), `Community` (Twitter, Discord, Mirror, Github), `Legal` (Terms, Privacy, Risk disclosure). Each: mono uppercase header + 13.5px links, gap 10.
   - Bottom strip: `paddingTop: 24`, top border 1px. Left: `© 2024 XIVE Labs · open-source under MIT` (12px mono mute). Right: green dot + `All systems normal`.

### Dashboard — disconnected

**File:** `hifi-minimal.jsx` → `MinimalDashboard connected={false}`. **Width:** 1440. **Height:** 900.

Same shell as the connected dashboard but the user-data area is replaced by a Connect prompt.

- **Sidebar** (220px wide, full height, right border):
  - Logo block (XIVE + BETA), padding 4px 12px 22px.
  - 5 nav items — `Overview` (active, `surface` background), `Borrow` (dimmed 0.5), `Earn` (dimmed), `Markets`, `Activity` (dimmed). Each: 8px 12px, `border-radius: 6`, 13.5px, `textDim` for inactive. Icons: `◐ ↓ ↑ ◇ ≡` (14px, 0.7 opacity).
  - **Bottom card (different from connected):** padding 12, `surface` bg, `border-radius: 8`. Mono uppercase `PROTOCOL` header, then a green dot + `Live · Mainnet`. (No user health card.)

- **Topbar** (56px tall, bottom border, padding `0 32px`):
  - Left: live ticker — green dot + `ETH $3,400.20 · +2.14%` (12px, mono number in green).
  - Right: **`Connect wallet →` primary button** (no address pill, no avatar).

- **Body** (`padding: 28px 32px`, fades in with `PageFade`):
  - Two-column grid (`1.5fr 1fr`, gap 20):
    - **Left — Connect panel** (`MinimalConnectPanel`): `surface` card, 1px border, `border-radius: 10`, `padding: 64px 48px`, `min-height: 560`. Centered content with a soft accent halo at the top. Inside: a 56×56 indigo-tinted glyph (`◐`), a mono uppercase kicker `WALLET NOT CONNECTED`, a 32px headline `Connect to continue`, a 14px paragraph (Connect a wallet to open positions, mint XUSD against your collateral, and earn yield from the savings vault.), then `Connect wallet →` primary + `Learn more` ghost buttons. Below a top border, a 3-cell stat strip: `$24.6M / TVL`, `$9.2M / Total borrowed`, `8.4% / Savings APY`.
    - **Right — Accepted collaterals card** (`MinimalCollateralsCard`): see "Accepted collaterals" component below. Identical to the connected dashboard.

### Dashboard — connected (Overview)

**File:** `hifi-minimal.jsx` → `MinimalDashboard`. **Width:** 1440. **Height:** 900.

- **Sidebar** — same nav, but bottom card shows user-facing **Health**: `Health` label, green dot + `All systems normal`, mono mute footer `v0.4.2 · uptime 99.98%`.

- **Topbar** — same left ticker. Right: address pill (`6px 10px`, mono, 12px, green dot + `0x84f2…3e1c`) + 30×30 round avatar with a 135° gradient `accent → #c084fc`.

- **Header** (`MinimalHeader`, margin-bottom 24):
  - Mono uppercase kicker `OVERVIEW`.
  - H1 30px, weight 500, `-0.025em`: `Good evening, Alex.`
  - Right side: `Earn XUSD` ghost + `Borrow →` primary.

- **KPI row** (`MinimalKpiRow`): `surface` strip with 4 cells separated by 1px borders. Each cell: 11.5px mono uppercase label, 28px mono value (color depends on cell), 12px mono delta+sub line.
  - `Net worth` — `$11,180`, `+$240` (green) `last 24h`.
  - `Total borrowed` — `$6,500`, `0.5% APR`.
  - `Earning` — `$5,047` (accent color), `8.4% APY`.
  - `Health factor` — `2.19×` (green), `liq. at $2,320`.
  - Numbers tick up on mount via `TickerNum` / `TickerUSD`.

- **Body grid** (`1.5fr 1fr`, gap 20, margin-top 20):
  - **Left — Your positions** (`MinimalPositions`): `surface` card. Header: `Your positions` 14px + `View all →` (12px textDim). Table header (mono uppercase 11px): `Position / Collateral / Debt / LTV / Health` (`grid-template-columns: 1.4fr 1fr 1fr 1.5fr 80px`, gap 16). Each row (`StaggerItem`, hover bg `surfaceHi`):
    - Coin badge (30px circle, `surfaceHi` bg, mono token ticker first 2 chars).
    - Token name + `#1001` mono mute id.
    - Right-aligned mono: collateral amount + USD value below.
    - Right-aligned mono: debt + `XUSD` mute below.
    - LTV: `46% / max 80%` row, then `AnimBar` (height 4, accent for ltv ≤ 60, amber > 60).
    - Health factor (green if ≥ 1.5, amber otherwise), right-aligned, mono.
  - **Right rail — Side panel** (`MinimalSidePanel`):
    - **Accepted collaterals** card (replaces the older "Savings vault" card).
    - **Recent activity** card.

### Accepted collaterals — component (used on both dashboards)

**File:** `hifi-minimal.jsx` → `MinimalCollateralsCard`. Critical reusable component.

- `surface` card, 1px border, `border-radius: 10`, `overflow: hidden`.
- Header (padding `16px 20px 12px`, bottom border): mono uppercase `ACCEPTED COLLATERALS` left, mono mute `2 assets` right.
- Column header row (mono uppercase 10.5px, padding `10px 20px`, bottom border): `Asset / Max LTV / Liq. thr. / Oracle`, `grid-template-columns: 1.4fr 0.8fr 0.9fr 1fr`, gap 12.
- Two rows (`ETH`, `wBTC`):
  - **Default state**: 30px circular coin badge with the token's brand color (ETH: `Ξ` glyph, indigo bg `rgba(99, 102, 241, 0.12)` + accent text; wBTC: `₿` glyph, `rgba(247, 147, 26, 0.14)` bg + `#f7931a` text). Token symbol + full name. Right-aligned mono: `80%` / `85%` / `$3,284.50` for ETH; `75%` / `82%` / `$67,420.00` for wBTC.
  - **Hover state**: row background fades to `rgba(99, 102, 241, 0.06)`. The 4-column row crossfades out and a new layer crossfades in: same coin badge, `Borrow against ETH` 13.5px / weight 500, `up to 80% LTV` 11px mono mute, and a `Open position →` primary button on the right (padding `8px 14px`, fontSize 12.5). 160ms ease, with a 4px translate-X on the hover state for polish.

When the user clicks a row, route to **Borrow flow** preselected to that collateral. Click target is the entire row (cursor pointer).

### Recent activity — component

**File:** `hifi-minimal.jsx` → `MinimalSidePanel` (second card).

- `surface` card, header `padding: 16px 20px 12px`: mono uppercase `RECENT ACTIVITY` + `All →` mute link.
- Rows (padding `10px 20px`, fontSize 13): a small dot (6px, green if positive yield, mute otherwise) + activity type (textDim, 12.5px) on the left, mono amount + mono mute time-ago on the right.
- Mock data: `Borrow / +2,000 XUSD / 6d`, `Deposit / +1.20 ETH / 12d`, `Yield / +$4.80 / 14d (good)`, `Open / ETH position / 18d`.

### Borrow flow

**File:** `hifi-a-flows-1.jsx` → `MinimalBorrow`.

Three-column layout inside `MinimalShell active="Borrow"`:

1. **Header** — mono kicker `BORROW XUSD` + H1 30px `Open a position`.
2. **Left rail** — collateral selector. Each collateral asset is a card; clicking selects it. Shows price, max LTV, liquidation threshold, oracle delay.
3. **Center** — collateral amount input (large 30–40px mono number, with `Max` and `50%` chips), then a slider for `Borrow amount` (XUSD) with `min: 0, max: collateralUsd * maxLtv / 100`.
4. **Right rail** — live preview card: `Liquidation price`, `Health factor` (animated, color-coded), `Borrow APR`, `Estimated gas`. A primary CTA at the bottom: `Continue → confirm`.

The user fills both inputs; the right-rail preview updates live (use Framer Motion's `useSpring` on the numbers for the satisfying tick-up).

### Earn flow

**File:** `hifi-a-flows-1.jsx` → `MinimalEarn`.

Two-column inside `MinimalShell active="Earn"`:

- **Left** — vault stats card (TVL, current APY large + accent color, 30-day APY chart placeholder), explanation copy ("Yield comes from positions the vault liquidates at a discount. No lockup; withdraw at any time.").
- **Right** — deposit / withdraw tabs. Amount input (XUSD), preview of new vault share %, `Deposit XUSD →` primary CTA.

### Manage position

**File:** `hifi-a-flows-2.jsx` → `MinimalManage`.

Header: breadcrumb `Overview / ETH position #1001`, then a card showing the position with token glyph, name (`ETH position`, 24px), id+open-date.

Five-tab control:
- **Add** collateral
- **Withdraw** collateral
- **Borrow** more XUSD
- **Repay** XUSD
- **Close** position (special — see `MinimalClosePosition`)

Each tab: amount input + preview block (`New debt`, `New health`, `New liq. price`) + tab-specific CTA. Close tab: copy explaining "Repay your full $X XUSD debt and withdraw Y ETH collateral" + warning card (`Closing this position is final. You can always open a new one later.`) + red `Close position — repay X XUSD` button (the only red button in the system).

`MinimalManage atRisk` variant: shows an amber/red warning banner at the top, the position card uses amber accents, and the recommended-action chip is `Add collateral` or `Repay`.

### Confirm & transaction status

**File:** `hifi-a-flows-2.jsx`.

- **Confirmation modal** (`MinimalConfirm`): centered modal, 480 wide. Header `Review & confirm` + H2 `Open ETH position`. Three sections: action summary, fees breakdown, network info. Cancel ghost + `Confirm in wallet →` primary.
- **Tx pending** (`MinimalTxStatus phase="pending"`): full-width centered. Animated ring spinner (indigo). H1 `Opening your position…`. Subhead with tx hash (link). Detail rows. `View on explorer ↗` ghost button.
- **Tx confirmed** (`MinimalTxStatus phase="confirmed"`): green check icon. H1 `Position opened`. Detail rows. `View position` ghost + `Back to overview →` primary.

### Onboarding

**File:** `hifi-a-onboarding.jsx`.

- **Connect wallet** (`MinimalConnect`): split layout. Left: hero copy + 3-cell stat strip ($24.6M TVL, $9.2M XUSD outstanding, 8.4% APY). Right: connect card with 4 wallet rows (MetaMask, WalletConnect, Coinbase Wallet, Rabby). Hover swaps row bg/border. Footer: terms link + non-custodial disclaimer.
- **Empty dashboard** (`MinimalEmptyDash`): connected shell, but two big CTA cards instead of position list — `Borrow XUSD` (with indigo accent halo) and `Earn 8.4%`. Below: `In your wallet` token list with greyed-out (0.5 opacity) zero-balance rows.

---

## Interactions & behavior

### Routes (proposed)

```
/                       → Main (landing)
/app                    → Dashboard (Overview if connected, Connect prompt if not)
/app/borrow             → Borrow flow
/app/borrow?asset=eth   → Borrow with ETH preselected (from Accepted collaterals row click)
/app/earn               → Earn / savings vault
/app/positions/:id      → Manage position
/app/markets            → Markets list (out of scope but reserve the route)
/app/activity           → Activity (out of scope)
```

The Main page should never gate behind a wallet. The `/app/*` routes can render the disconnected dashboard variant when no wallet is connected — **do not redirect to a separate Connect page** (the disconnected dashboard already serves that role with the protocol stats visible).

### Wallet connection

- Top-right `Connect wallet` button on every screen when disconnected.
- On click: open the wallet picker modal (RainbowKit / ConnectKit recommended).
- Once connected, the disconnected dashboard transitions to the connected variant on the same route — animate the swap with `AnimatePresence`.
- Persist the connection in the wallet library; do not store anything sensitive.

### Hover states

- **Table rows** (positions, activity, collaterals): bg fades to `surfaceHi` over 150ms. Collateral rows additionally crossfade to the "Open position" CTA layer (160ms).
- **Buttons**: subtle `transition: all 150ms`. Primary stays as-is (already high contrast); ghost buttons can lift `borderHi → text` or bg to `rgba(255,255,255,0.04)`.
- **Sidebar items**: bg `surface` on hover.

### Form validation

- Borrow amount can't exceed `collateralUsd * maxLtv / 100`; show the cap inline on the slider.
- Required: collateral selected + amount > 0 + borrow amount > 0. Disable Continue button (`opacity 0.4, cursor not-allowed`) until valid.
- Live health-factor calculation on every keystroke. If it would result in `health < 1.2`, show an amber warning under the input.

### Loading states

- Use skeleton blocks (`surface` bg, subtle shimmer animation) for any data being fetched. Match the size of the final content. Don't use spinners for content; spinners are reserved for tx pending only.

### Error states

- Wallet connection rejected: toast (`surface` bg, amber dot, "Connection cancelled").
- Tx failed: dedicated screen variant (port from the wireframe `tx-flows.jsx` — there's a `phase="failed"` branch). Header `Transaction failed`, red icon, error message from chain, `Try again` primary + `Back` ghost.
- Wrong network: full-width banner above topbar, amber bg, `You're on the wrong network. Switch to Mainnet.` + `Switch network` button.

### Responsive behavior

The hifi mocks are 1440 desktop only. For implementation, plan three breakpoints:

- **≥ 1280**: as designed.
- **768–1279**: collapse sidebar to icon-only (56px wide). KPI row stays 4-up. Position grid becomes single-column.
- **< 768**: sidebar becomes a bottom tab bar (5 icons). KPI row becomes 2×2 grid. Cards stack. Tables become card lists. The Manage position tabs stay horizontal (scrollable).

Mobile screens are not in this handoff — design them to match the system, or coordinate a follow-up mobile pass.

---

## State management

Global state needs (suggested with Zustand or similar):

- `walletStore` — `address`, `chainId`, `isConnected`, `connect()`, `disconnect()`. Use wagmi hooks; this is a thin adapter.
- `protocolStore` — public protocol stats: `tvl`, `xusdSupply`, `savingsApy`, `activePositionCount`, `collateralAssets[]` (each with `symbol`, `name`, `oraclePrice`, `maxLtv`, `liqThreshold`, `liqPenalty`, `borrowApr`).
- `userStore` (only when connected) — `positions[]` (each: `id`, `collateralAsset`, `collateralAmount`, `debt`, `ltv`, `health`, `liqPrice`, `openedAt`), `vaultDeposit` ({ amount, share, yieldEarned }), `walletBalances`, `recentActivity[]`.

Refresh strategy: use wagmi's block-watch / SWR-style polling on a 12-second interval for prices and 30-second for protocol totals. Optimistically update after a confirmed tx, then reconcile from chain on the next refresh.

---

## Design tokens reference

```ts
// /src/styles/tokens.ts (suggested)

export const color = {
  bg:        '#0b0d10',
  surface:   '#13161b',
  surfaceHi: '#181c22',
  border:    'rgba(255,255,255,0.06)',
  borderHi:  'rgba(255,255,255,0.10)',

  text:      '#e9ecef',
  textDim:   '#8a9099',
  textMute:  '#5b6168',

  accent:    '#7c9bff',
  accentDim: 'rgba(124, 155, 255, 0.12)',

  green:     '#5fc28a',
  amber:     '#e6b450',
  red:       '#ec6f6f',

  // brand glyph backgrounds
  ethTint:  'rgba(99, 102, 241, 0.12)',
  ethFg:    '#7c9bff',
  btcTint:  'rgba(247, 147, 26, 0.14)',
  btcFg:    '#f7931a',
};

export const radius = {
  sm: 4,    // tags
  md: 6,    // buttons
  lg: 8,    // small cards
  xl: 10,   // cards
  xxl: 12,  // hero cards
  pill: 99,
};

export const space = [0, 2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 22, 24, 28, 32, 40, 48, 64, 80, 100];

export const motion = {
  fast: '150ms',
  med:  '160ms',
  slow: '400ms',
  ticker: '900ms',
  bar:    '600ms',
  ease:   'cubic-bezier(0.16, 1, 0.3, 1)', // ease-out-expo-ish
};
```

For Tailwind, drop these into `tailwind.config.ts`'s `theme.extend.colors`, `borderRadius`, `spacing`, `transitionTimingFunction`, and `transitionDuration`.

---

## Assets

No external image assets are used. All visual elements are CSS / inline SVG / Unicode glyphs:

- Coin glyphs are typographic: `Ξ` (ETH), `₿` (wBTC), `$` (XUSD).
- Icons are Unicode: `↑ ↓ ◐ ◇ ≡ → ↗ ✓` — replace these with proper icon components in production (lucide-react: `ArrowUp`, `ArrowDown`, `CircleDot`, `Diamond`, `Menu`, `ArrowRight`, `ExternalLink`, `Check`).
- The XIVE wordmark is set in Geist 600 with `-0.02em` tracking — no logo file. Treat as type for now; commission a real mark later if needed.
- Wallet logos in the Connect screen use Unicode placeholders (`🦊 ◇ ◉ ◐`). Replace with actual brand assets from each wallet's brand kit (MetaMask, WalletConnect, Coinbase Wallet, Rabby).

---

## Files in this bundle

| File | Purpose |
|---|---|
| `XIVE Hi-Fi Dashboard.html` | Open in browser to see all artboards in the design canvas. |
| `design-canvas.jsx` | The pan/zoom artboard host. **Not for production** — discard. |
| `hifi-shared.jsx` | Shared primitives: `MinimalShell`, `MCard`, `MLabel`, `mAccent`, `mGhost`, `PageFade`, `StaggerItem`, `TickerNum`, `TickerUSD`, `AnimBar`, `LiveDot`. **Port these as proper components.** |
| `hifi-minimal.jsx` | **Direction A core.** `MinimalDashboard`, `MinimalConnectPanel`, `MinimalCollateralsCard`, `MinimalSidebar`, `MinimalTopbar`, `MinimalKpiRow`, `MinimalPositions`, `MinimalSidePanel` (recent activity). |
| `hifi-main.jsx` | **Main / landing page.** `MinimalMain`, `MainNav`, `MainHero`, `MainWhat`, `MainHow`, `MainFooter`, `HowVisual`. |
| `hifi-a-flows-1.jsx` | `MinimalBorrow`, `MinimalEarn`. |
| `hifi-a-flows-2.jsx` | `MinimalManage`, `MinimalClosePosition`, `MinimalConfirm`, `MinimalTxStatus`. |
| `hifi-a-onboarding.jsx` | `MinimalConnect`, `MinimalEmptyDash`. |
| `hifi-trader.jsx`, `hifi-editorial.jsx` | **Reference only — Directions B and C.** Do not implement; they show palettes that were rejected. Useful only if a stakeholder asks "why this direction." |

---

## Implementation order (suggested)

1. **Set up tokens and primitives.** Tokens file, base layout (`AppShell` = sidebar + topbar + content), button components (primary, ghost), card primitive, label primitive, animation hooks (page fade, stagger, ticker, bar fill).
2. **Main page.** Static, no wallet, no data fetching. Validates the type system, animation hooks, and footer/nav patterns.
3. **Dashboard shell + Disconnected variant.** Routing, wallet hook, sidebar, topbar, Accepted collaterals card. The collaterals card is reused on both dashboard variants — build it once.
4. **Connected dashboard.** KPI row, positions table, recent activity. Hook up real data; placeholder values are fine until the contracts are integrated.
5. **Borrow flow.** First flow that mutates state. Includes confirmation modal + tx pending + tx confirmed.
6. **Manage position** (healthy first, then at-risk). Reuses the confirmation/tx pattern from Borrow.
7. **Earn flow.** Simpler than Borrow; reuse the confirmation/tx components.
8. **Onboarding states** (Empty dashboard, Connect modal polish).
9. **Edge cases.** Failed tx, wrong network, rejected connection, wallet switch.
10. **Mobile pass.** Coordinate breakpoints for the screens above.

---

## Open questions for the engineering team

These were not pinned down in design; flag them early so they don't block:

1. **Chain & contract addresses** — which network, which contract suite (looks Liquity-like / Maker-like)? Affects wallet adapter choice, oracle wiring, and gas-price feed.
2. **Collateral list source** — onchain enumeration vs. config file. Affects how the Accepted collaterals card is fed.
3. **Liquidation surface** — the savings vault absorbs liquidations, but no liquidator/keeper UI is in this handoff. Confirm whether keepers run separately or whether there's a UI surface for advanced users.
4. **Real wallet logos and copy review** — terms/privacy pages aren't drafted. Get legal in early.
5. **Translation / i18n** — copy is English-only and not externalized. If multi-language is on the roadmap, set up i18n infrastructure on day 1.
6. **Accessibility audit** — color contrast for `textDim` (`#8a9099` on `#0b0d10`) is around 5.4:1 — passes AA for body text. `textMute` (`#5b6168`) is closer to 3.7:1 — only use for decorative / mono labels at 11px+, not body. Verify with axe / lighthouse before launch.
