// Shared utilities for hi-fi dashboards
// Animated number ticker — counts up to target on mount

const useTicker = (target, { duration = 1200, decimals = 0 } = {}) => {
  const [val, setVal] = React.useState(0);
  React.useEffect(() => {
    const start = performance.now();
    const from = 0;
    let raf;
    const step = (now) => {
      const t = Math.min(1, (now - start) / duration);
      // easeOutCubic
      const eased = 1 - Math.pow(1 - t, 3);
      setVal(from + (target - from) * eased);
      if (t < 1) raf = requestAnimationFrame(step);
    };
    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
  }, [target, duration]);
  return decimals === 0 ? Math.round(val) : val.toFixed(decimals);
};

// Animated bar — fills to width % on mount
const AnimBar = ({ pct, height = 6, color = '#fff', track = 'rgba(255,255,255,0.08)', radius = 99, delay = 0, duration = 1100 }) => {
  const [w, setW] = React.useState(0);
  React.useEffect(() => {
    const t = setTimeout(() => setW(pct), delay);
    return () => clearTimeout(t);
  }, [pct, delay]);
  return (
    <div style={{ height, background: track, borderRadius: radius, overflow: 'hidden', position: 'relative' }}>
      <div style={{
        height: '100%', width: `${w}%`, background: color,
        borderRadius: radius,
        transition: `width ${duration}ms cubic-bezier(0.16, 1, 0.3, 1)`,
      }} />
    </div>
  );
};

// Format helpers
const fmtUSD = (n) => '$' + n.toLocaleString('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 0 });
const fmtNum = (n, dp = 2) => n.toLocaleString('en-US', { minimumFractionDigits: dp, maximumFractionDigits: dp });

// Page-fade wrapper — fades in on mount for "page transition" feel
const PageFade = ({ children, style }) => {
  const [show, setShow] = React.useState(false);
  React.useEffect(() => {
    const t = setTimeout(() => setShow(true), 30);
    return () => clearTimeout(t);
  }, []);
  return (
    <div style={{
      ...style,
      opacity: show ? 1 : 0,
      transform: show ? 'translateY(0)' : 'translateY(8px)',
      transition: 'opacity 600ms ease-out, transform 600ms cubic-bezier(0.16, 1, 0.3, 1)',
    }}>{children}</div>
  );
};

// Stagger child reveal helper
const Stagger = ({ children, delay = 60, base = 100 }) => {
  return React.Children.map(children, (child, i) => (
    <StaggerItem delay={base + i * delay}>{child}</StaggerItem>
  ));
};
const StaggerItem = ({ children, delay }) => {
  const [show, setShow] = React.useState(false);
  React.useEffect(() => {
    const t = setTimeout(() => setShow(true), delay);
    return () => clearTimeout(t);
  }, [delay]);
  return (
    <div style={{
      opacity: show ? 1 : 0,
      transform: show ? 'translateY(0)' : 'translateY(6px)',
      transition: 'opacity 500ms ease-out, transform 500ms cubic-bezier(0.16, 1, 0.3, 1)',
    }}>{children}</div>
  );
};

// Format big USD with commas — animated
const TickerUSD = ({ to, decimals = 0, prefix = '$' }) => {
  const v = useTicker(to, { duration: 1400, decimals });
  const num = decimals === 0 ? Number(v).toLocaleString() : Number(v).toLocaleString('en-US', { minimumFractionDigits: decimals, maximumFractionDigits: decimals });
  return <>{prefix}{num}</>;
};

const TickerNum = ({ to, decimals = 2, suffix = '' }) => {
  const v = useTicker(to, { duration: 1400, decimals });
  const num = Number(v).toLocaleString('en-US', { minimumFractionDigits: decimals, maximumFractionDigits: decimals });
  return <>{num}{suffix}</>;
};

Object.assign(window, {
  useTicker, AnimBar, fmtUSD, fmtNum,
  PageFade, Stagger, StaggerItem,
  TickerUSD, TickerNum,
});
